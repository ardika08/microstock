var e,t;"function"==typeof(e=globalThis.define)&&(t=e,e=null),function(t,F,a,r,n){var i="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},o="function"==typeof i[r]&&i[r],s=o.cache||{},l="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function f(e,F){if(!s[e]){if(!t[e]){var a="function"==typeof i[r]&&i[r];if(!F&&a)return a(e,!0);if(o)return o(e,!0);if(l&&"string"==typeof e)return l(e);var n=Error("Cannot find module '"+e+"'");throw n.code="MODULE_NOT_FOUND",n}c.resolve=function(F){var a=t[e][1][F];return null!=a?a:F},c.cache={};var d=s[e]=new f.Module(e);t[e][0].call(d.exports,c,d,d.exports,this)}return s[e].exports;function c(e){var t=c.resolve(e);return!1===t?{}:f(t)}}f.isParcelRequire=!0,f.Module=function(e){this.id=e,this.bundle=f,this.exports={}},f.modules=t,f.cache=s,f.parent=o,f.register=function(e,F){t[e]=[function(e,t){t.exports=F},{}]},Object.defineProperty(f,"root",{get:function(){return i[r]}}),i[r]=f;for(var d=0;d<F.length;d++)f(F[d]);if(a){var c=f(a);"object"==typeof exports&&"undefined"!=typeof module?module.exports=c:"function"==typeof e&&e.amd?e(function(){return c}):n&&(this[n]=c)}}({WfXo6:[function(e,t,F){let a;var r=e("@parcel/transformer-js/src/esmodule-helpers.js");r.defineInteropFlag(F),r.export(F,"config",()=>l);var n=e("data-base64:~assets/icon.png"),i=r.interopDefault(n),o=e("~/lib/openai"),s=e("~/lib/storage");let l={matches:["https://contributor.stock.adobe.com/*","https://stock.adobe.com/*","https://submit.shutterstock.com/*","https://contributor-accounts.shutterstock.com/*"],run_at:"document_idle"},f={title:['input[name="title"]','textarea[name="title"]','textarea[placeholder*="title" i]','input[placeholder*="title" i]','textarea[aria-label*="title" i]','input[aria-label*="title" i]','[data-testid*="title" i] input','[data-testid*="title" i] textarea','textarea[maxlength="200"]'],description:['textarea[name="description"]','input[name="description"]','[data-testid*="description" i] textarea','[data-testid*="description" i] input','textarea[placeholder*="description" i]'],keywords:['textarea[name="keywords"]','input[name="keywords"]','textarea[placeholder*="keyword" i]','input[placeholder*="keyword" i]','textarea[aria-label*="keyword" i]','input[aria-label*="keyword" i]','[data-testid*="keyword" i] textarea','[data-testid*="keyword" i] input','[class*="keyword" i] textarea','[class*="keyword" i] input'],category:['select[name="category"]','[data-testid*="category" i] select','select[aria-label*="category" i]']},d={description:'textarea[name="description"]',keywordInput:'input[placeholder="Add keyword, separated by a comma or semicolon"]',assetMedia:'img[data-testid^="card-media-"]',category1:'#mui-component-select-category1, [aria-labelledby="mui-component-select-category1"]'},c=["Animals/Wildlife","Arts","Backgrounds/Textures","Buildings/Landmarks","Business/Finance","Education","Food and drink","Healthcare/Medical","Holidays","Industrial","Nature","Objects","People","Religion","Science","Signs/Symbols","Sports/Recreation","Technology","Transportation"],A="adobestock-autofill-trigger",B="adobestock-autofill-layout-style";function u(e){for(let t of e){let e=document.querySelector(t);if(e)return e}return null}function w(e){let t=e.getBoundingClientRect(),F=window.getComputedStyle(e);return t.width>20&&t.height>20&&"none"!==F.display&&"hidden"!==F.visibility}function g(){let e=document.body.innerText||"";return location.hostname.includes("submit.shutterstock.com")&&/shutterstock\s*contributor/i.test(e)&&/Not submitted/i.test(e)&&!!document.querySelector(d.description)&&!!document.querySelector(d.keywordInput)}function p(e){return e?.selected_microstock==="shutterstock"||g()?"shutterstock":"adobe_stock"}function h(){document.getElementById(A)?.remove(),document.getElementById(B)?.remove(),document.documentElement.style.removeProperty("--asaf-panel-width"),document.documentElement.style.removeProperty("--asaf-content-shift"),document.documentElement.classList.remove("asaf-panel-active")}async function m(e,t){if("undefined"!=typeof chrome&&chrome.runtime)try{await chrome.runtime.sendMessage({type:"ADOBESTOCK_NOTIFY_COMPLETE",payload:{processed:e,platform:t}})}catch{}}function P(e){return!!e.panel_enabled&&("adobe_stock"===e.selected_microstock?function(){let e=document.body.innerText||"";return/Submit\s+\d+\s+files?/i.test(e)&&/Include in submission/i.test(e)&&/File type/i.test(e)&&/KEYWORDS/i.test(e)}():"shutterstock"===e.selected_microstock&&g())}function D(){if(g()){let e=document.querySelector(d.keywordInput);if(e&&w(e))return e}let e=u(f.keywords);if(e&&w(e))return e;let t=u(f.title),F=t?.getBoundingClientRect().bottom||0,a=Array.from(document.querySelectorAll("textarea, input[type='text'], [contenteditable='true']")).filter(e=>{let t=e.getBoundingClientRect(),a=e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement?e.placeholder:"";return w(e)&&t.bottom>F&&!a.toLowerCase().includes("title")&&!a.toLowerCase().includes("search")});return a.sort((e,t)=>e.getBoundingClientRect().top-t.getBoundingClientRect().top)[0]}function v(e){e.dispatchEvent("undefined"!=typeof InputEvent?new InputEvent("input",{bubbles:!0,data:null,inputType:"insertText"}):new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),e.dispatchEvent(new Event("blur",{bubbles:!0}))}function b(e,t){if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){e.focus();let F=e instanceof HTMLInputElement?HTMLInputElement.prototype:HTMLTextAreaElement.prototype,a=Object.getOwnPropertyDescriptor(F,"value");return a?.set?.call(e,t),e.value=t,v(e),!0}if(e instanceof HTMLSelectElement){let F=Array.from(e.options).find(e=>e.text.toLowerCase().trim()===t.toLowerCase().trim());return!!F&&(e.value=F.value,v(e),!0)}return!!e.isContentEditable&&(e.textContent=t,v(e),!0)}function y(e){let t=e,F=e;for(let e=0;t&&e<7;e+=1){let e=t.getBoundingClientRect(),a=/Needs attention|Submitted|Rejected|Pending/i.test(t.textContent||"");if(w(t)&&e.width>=180&&e.width<=420&&e.height>=150&&e.height<=360&&a&&(F=t),!t.parentElement||t.parentElement===document.body)break;t=t.parentElement}return F}function x(){let e=Array.from(document.querySelectorAll(d.assetMedia)).filter(e=>w(e)&&!e.closest(`#${A}`)),t=e.map(y),F=Array.from(new Set(t));return F.sort((e,t)=>{let F=e.getBoundingClientRect(),a=t.getBoundingClientRect();return F.top-a.top||F.left-a.left})}function H(){let e=z();if(e)return e;let t=L(x()),F=t?.querySelector(d.assetMedia)||document.querySelector(d.assetMedia);return F?.dataset.testid?.replace(/^card-media-/,"").trim()||F?.getAttribute("data-testid")?.replace(/^card-media-/,"").trim()||""}function z(){let e=Array.from(document.querySelectorAll("h1, h2, h3, strong, p")).map(e=>(e.textContent||"").trim()).find(e=>/\.(mov|mp4|jpg|jpeg|png|eps|ai)$/i.test(e));return e||""}function M(e){let t=H(),F=[t,e.title].join(" ").toLowerCase(),a=[t,e.category,e.title,e.description,e.keywords.join(" ")].join(" ").toLowerCase(),r=e=>e.some(e=>e.test(a)),n=e=>e.some(e=>e.test(F));if(n([/background|texture|gradient|abstract|pattern|wallpaper|backdrop|surface/]))return"Backgrounds/Textures";if(n([/technology|digital|computer|software|network|data|ai|robot|cyber/]))return"Technology";if(n([/art|design|illustration|graphic|creative|paint|drawing/]))return"Arts";let i=c.find(t=>t.toLowerCase()===e.category.toLowerCase().trim());return i||(r([/background|texture|gradient|abstract|pattern|wallpaper|backdrop|surface/])?"Backgrounds/Textures":r([/animal|wildlife|pet|bird|fish|dog|cat|insect/])?"Animals/Wildlife":r([/building|landmark|architecture|city|urban|house|interior|exterior/])?"Buildings/Landmarks":r([/business|finance|money|office|corporate|market|investment|economy/])?"Business/Finance":r([/education|school|student|learning|classroom|teacher|book/])?"Education":r([/food|drink|beverage|meal|restaurant|fruit|coffee/])?"Food and drink":r([/health|medical|doctor|medicine|hospital|wellness|clinic/])?"Healthcare/Medical":r([/holiday|christmas|halloween|easter|valentine|celebration|festival/])?"Holidays":r([/industrial|factory|machine|manufacturing|construction|engineering/])?"Industrial":r([/nature|landscape|forest|flower|plant|mountain|ocean|sky|water/])?"Nature":r([/object|product|item|tool|device|equipment|isolated/])?"Objects":r([/people|person|woman|man|child|family|portrait|human/])?"People":r([/religion|church|mosque|temple|spiritual|faith/])?"Religion":r([/science|laboratory|research|chemistry|biology|physics|space/])?"Science":r([/sign|symbol|icon|label|arrow|warning|infographic/])?"Signs/Symbols":r([/sport|fitness|exercise|game|recreation|athlete|ball/])?"Sports/Recreation":r([/technology|digital|computer|software|network|data|ai|robot|cyber/])?"Technology":r([/transport|car|vehicle|truck|train|plane|ship|traffic/])?"Transportation":(r([/art|design|illustration|graphic|creative|paint|drawing/]),"Arts"))}function C(e,t,F){for(let a of["pointerdown","mousedown","pointerup","mouseup","click"]){let r={bubbles:!0,cancelable:!0,clientX:t,clientY:F,view:window};a.startsWith("pointer")&&"undefined"!=typeof PointerEvent?e.dispatchEvent(new PointerEvent(a,{...r,pointerId:1,pointerType:"mouse",isPrimary:!0})):e.dispatchEvent(new MouseEvent(a,r))}}async function E(e){for(let t=0;t<3;t+=1){let t=e.getBoundingClientRect(),F=t.right-14,a=t.top+t.height/2,r=document.elementFromPoint(F,a),n=r instanceof HTMLElement&&!r.closest(`#${A}`)?r:e;if(e.focus(),C(n,F,a),C(e,F,a),await X(250),document.querySelector('[role="listbox"], .MuiMenu-paper, .MuiPopover-paper, ul.MuiList-root'))return!0}return!1}async function k(e){let t=M(e),F=document.querySelector(d.category1);if(!F)return!1;let a=F.textContent?.replace(/\u200B/g,"").trim()||"";if(a.toLowerCase()===t.toLowerCase())return!0;let r=await E(F);if(!r)return!1;for(let e=0;e<10;e+=1){let e=Array.from(document.querySelectorAll('[role="option"], .MuiMenuItem-root, li.MuiMenuItem-root, [data-value]')).filter(e=>{let F=e.textContent?.replace(/\u200B/g,"").trim()||"";return w(e)&&F===t}),a=e[0];if(a){let e=a.getBoundingClientRect(),r=document.elementFromPoint(e.left+e.width/2,e.top+e.height/2),n=r instanceof HTMLElement&&!r.closest(`#${A}`)?r:a;C(n,e.left+e.width/2,e.top+e.height/2),C(a,e.left+e.width/2,e.top+e.height/2),a.click(),await X(500);let i=F.textContent?.replace(/\u200B/g,"").trim().toLowerCase()||"";if(i===t.toLowerCase())return!0;return!!Array.from(document.querySelectorAll("body *")).find(e=>e.textContent?.replace(/\u200B/g,"").trim()===t&&/select|category|value/i.test(`${e.className||""} ${e.id||""}`))}await X(200)}return!1}async function O(e){let t=e.keywords.join(", ");if(g()){let e=document.querySelector(d.keywordInput);return!!e&&(b(e,t),e.dispatchEvent(new KeyboardEvent("keydown",{bubbles:!0,cancelable:!0,key:",",code:"Comma"})),e.dispatchEvent(new KeyboardEvent("keyup",{bubbles:!0,cancelable:!0,key:",",code:"Comma"})),v(e),await X(500),!0)}for(let F=0;F<4;F+=1){let F=D();if(!F){await X(300);continue}b(F,t),await X(250);let a=F instanceof HTMLInputElement||F instanceof HTMLTextAreaElement?F.value:F?.textContent||"";if(a.includes(e.keywords[0]||"")||a.length>20)return!0}return!1}async function I(e){if(g()){let t={...e,category:M(e)},F={description:!1,keywords:!1,category:!1},a=document.querySelector(d.description);if(a&&(F.description=b(a,t.description)),F.category=await k(t),F.keywords=await O(t),await X(250),!F.description&&!F.keywords&&!F.category)throw Error("Tidak menemukan field Shutterstock yang bisa diisi.");return F}let t={title:!1,description:!1,keywords:!1,category:!1},F=u(f.title);F&&(t.title=b(F,function(e){let t=e.replace(/\s+/g," ").trim();if(t.length<=190)return t;let F=t.slice(0,190),a=F.lastIndexOf(" ");return F.slice(0,a>80?a:190).trim()}(e.description||e.title)));let a=u(f.description);a&&(t.description=b(a,e.description)),t.keywords=await O(e);let r=u(f.category);r&&e.category&&(t.category=b(r,e.category)),await new Promise(e=>window.setTimeout(e,250));let n=Object.values(t).filter(Boolean).length;if(0===n)throw Error("Tidak menemukan field Adobe Stock yang bisa diisi.");return t}function X(e){return new Promise(t=>window.setTimeout(t,e))}async function j(e,t){let F=Math.ceil(t/1e3);for(let t=F;t>0;t-=1)V(e,`Menunggu ${t} detik sebelum file berikutnya...`,"muted"),await X(1e3)}function S(){if(g())return x();let e=Math.max(320,Math.min(.68*window.innerWidth,window.innerWidth-345-420)),t=t=>{let F=t.getBoundingClientRect();return w(t)&&!t.closest(`#${A}`)&&F.width>=70&&F.width<=320&&F.height>=70&&F.height<=320&&F.top>80&&F.left>=0&&F.left<e},F=t=>{let F=t.getBoundingClientRect(),a=window.getComputedStyle(t),r=a.backgroundColor,n=a.backgroundImage,i=String(t.className||""),o=t.getAttribute("aria-label")||"",s=(t.textContent||"").trim(),l=["IMG","VIDEO","CANVAS"].includes(t.tagName),f=/rgb\((?:2[0-5]\d|1\d\d),\s*(?:[4-9]\d|1\d\d|2[0-5]\d),\s*(?:1[0-9]\d|2[0-5]\d)\)/.test(r)||/pink|thumbnail|asset|file|upload/i.test(`${i} ${o}`),d=F.width>=80&&F.width<=260&&F.height>=80&&F.height<=260&&F.top>80&&F.left>=0&&F.left<e;return d&&s.length<120&&(l||"none"!==n||f)},a=t=>{let F=t,a=t;for(let t=0;F&&t<5;t+=1){let t=F.getBoundingClientRect(),r=F.parentElement,n=(F.textContent||"").trim(),i=!!(F.querySelector("input, textarea, select, button")||/File type|Category|KEYWORDS|Recognizable people/i.test(n));if(!i&&t.width>=90&&t.width<=300&&t.height>=90&&t.height<=300&&t.left<e&&(a=F),!r||r===document.body||r.closest(`#${A}`))break;F=r}return a},r=Array.from(document.querySelectorAll("img, video, canvas, div, li, article, [role='button'], [tabindex]")).filter(e=>!(!w(e)||e.closest(`#${A}`))&&F(e)),n=e=>{let F=e.getBoundingClientRect(),a=(e.textContent||"").trim();return t(e)&&F.width>=80&&F.height>=80&&!e.querySelector("input, textarea, select")&&!/File type|Category|KEYWORDS|Recognizable people|Submit/i.test(a)},i=r.map(e=>{let t=e.closest("[role='button'], button, [tabindex], li, article");return t&&n(t)?t:a(e)}).filter(n),o=Array.from(new Set(i)).filter(e=>!Array.from(new Set(i)).some(t=>{if(t===e||!t.contains(e))return!1;let F=t.getBoundingClientRect(),a=e.getBoundingClientRect();return F.width<=a.width+40})),s=[];for(let e of o){let t=e.getBoundingClientRect(),F=Math.round(t.left+t.width/2),a=Math.round(t.top+t.height/2),r=s.some(e=>{let t=e.getBoundingClientRect(),r=Math.round(t.left+t.width/2),n=Math.round(t.top+t.height/2);return 12>Math.abs(r-F)&&12>Math.abs(n-a)});r||s.push(e)}return s.sort((e,t)=>{let F=e.getBoundingClientRect(),a=t.getBoundingClientRect();return F.top-a.top||F.left-a.left})}function L(e=S()){return e.find(e=>N(e))}function T(e=function(e=S()){return L(e)||e[0]}()){if(!e)return"";let t=e.querySelector(d.assetMedia);if(t?.currentSrc)return t.currentSrc;if(t?.src)return t.src;let F=e.querySelector("img, video");if(F instanceof HTMLImageElement&&F.currentSrc)return F.currentSrc;if(F instanceof HTMLImageElement&&F.src)return F.src;if(F instanceof HTMLVideoElement&&F.poster)return F.poster;let a=[e,...Array.from(e.querySelectorAll("*"))].find(e=>"none"!==window.getComputedStyle(e).backgroundImage),r=a?window.getComputedStyle(a).backgroundImage:"",n=r.match(/url\(["']?(.*?)["']?\)/);return n?.[1]||""}function N(e){let t=`${e.className||""} ${e.getAttribute("aria-selected")||""}`,F=[e,...Array.from(e.querySelectorAll("*")).slice(0,12)],a=F.some(e=>{let t=window.getComputedStyle(e),F=`${t.borderColor} ${t.outlineColor} ${t.boxShadow}`,a=Number.parseFloat(t.borderTopWidth||"0"),r=Number.parseFloat(t.outlineWidth||"0"),n=/(?:0,\s*120,\s*255|37,\s*99,\s*235|20,\s*115,\s*230|38,\s*128,\s*235|0,\s*102,\s*255)/.test(F);return n&&(a>=1||r>=1||"none"!==t.boxShadow)});return"true"===e.getAttribute("aria-selected")||/selected|active|current/i.test(t)||a}function Q(e,t,F){for(let a of["pointerdown","mousedown","mouseup","click"])e.dispatchEvent(new MouseEvent(a,{bubbles:!0,cancelable:!0,clientX:t,clientY:F,view:window}))}async function q(e){e.scrollIntoView({block:"center",inline:"center"}),await X(150);let t=Array.from(e.querySelectorAll("img, video, canvas, div")).filter(e=>{let t=e.getBoundingClientRect(),F=window.getComputedStyle(e),a=["IMG","VIDEO","CANVAS"].includes(e.tagName)||"none"!==F.backgroundImage||"rgba(0, 0, 0, 0)"!==F.backgroundColor;return a&&t.width>=70&&t.height>=70&&t.width<=300&&t.height<=260}).sort((e,t)=>{let F=e.getBoundingClientRect(),a=t.getBoundingClientRect();return a.width*a.height-F.width*F.height})[0]||e,F=t.getBoundingClientRect(),a=F.left+F.width/2,r=F.top+F.height/2,n=document.elementFromPoint(a,r),i=n instanceof HTMLElement&&!n.closest(`#${A}`)?n:e;Q(i,a,r),Q(e,a,r),await X(700)}async function G(e){let t=g()&&e.querySelector(d.assetMedia)?.getAttribute("data-testid")?.replace(/^card-media-/,"").trim()||"";await q(e);for(let F=0;F<16;F+=1){if(t){let e=z();if(e&&e===t)return!0}let F=S(),a=L(F),r=a?.getBoundingClientRect(),n=e.getBoundingClientRect(),i=F.find(e=>{let t=e.getBoundingClientRect();return 8>Math.abs(t.left-n.left)&&8>Math.abs(t.top-n.top)});if(r&&8>Math.abs(r.left-n.left)&&8>Math.abs(r.top-n.top)||i&&N(i))return!0;await X(250)}return!1}async function K(){if(g()){for(let e=0;e<10;e+=1){await X(250);let e=document.querySelector(d.description),t=document.querySelector(d.keywordInput);if(e&&t&&w(e)&&w(t)){await X(500);return}}await X(900);return}for(let e=0;e<10;e+=1){await X(250);let e=u(f.title),t=D();if(e&&t&&w(e)&&w(t)){await X(500);return}}await X(900)}function V(e,t,F="muted"){let a=e.querySelector("[data-asaf-footer]");a&&(a.textContent=t,a.dataset.type=F)}function R(e,t,F){let a=e.querySelector("[data-asaf-category-preview]"),r=e.querySelector("[data-asaf-title-preview]"),n=e.querySelector("[data-asaf-keyword-preview]"),i=e.querySelector("[data-asaf-thumbnail]"),o=e.querySelector("[data-asaf-thumbnail-placeholder]"),s=T();if(s&&i?(i.src=s,i.hidden=!1,o&&(o.hidden=!0)):o&&(o.hidden=!1,i&&(i.hidden=!0)),a){let e=document.createElement("span");e.className="asaf-spinner",a.textContent="",a.appendChild(e),a.appendChild(document.createTextNode(" Memproses kategori...")),a.dataset.loading="true"}if(r){let e=document.createElement("span");e.className="asaf-spinner",r.textContent="",r.appendChild(e),r.appendChild(document.createTextNode(" Memproses judul...")),r.dataset.loading="true"}if(n){let e=document.createElement("span");e.className="asaf-spinner",n.textContent="",n.appendChild(e),n.appendChild(document.createTextNode(" Memproses keyword...")),n.dataset.loading="true"}V(e,`Memproses aset ke ${t}/${F}`,"processing")}function Z(e,t,F="Generate"){let a=e.querySelector("[data-asaf-generate]");a&&(a.disabled=t,a.textContent=t?"Generating...":F)}async function U(){let e=await (0,s.getSettings)();P(e)?function(e){if(!P(e)||document.getElementById(A))return;let t=p(e);if(!document.getElementById(B)){let e=document.createElement("style");e.id=B,e.textContent="",document.head.appendChild(e)}let F=function(e,t={},F){let a=document.createElement("div");for(let[e,F]of Object.entries(t))a.setAttribute(e,F);return F&&(a.textContent=F),a}(0,{id:A});F.style.position="fixed",F.style.right="0",F.style.top="0",F.style.width="380px",F.style.height="100vh",F.style.zIndex="2147483647",F.style.pointerEvents="auto";let a=F.attachShadow({mode:"open"});a.innerHTML=`
    <style>
      :host {
        color-scheme: dark;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      }

      * { box-sizing: border-box; }

      .asaf-panel {
        position: relative;
        z-index: 2;
        width: 100%;
        height: 100vh;
        overflow: auto;
        border-left: 1px solid rgba(255,255,255,0.08);
        background: #020617;
        color: #e2e8f0;
        box-shadow: -18px 0 48px rgba(2, 6, 23, 0.55);
        pointer-events: auto;
      }

      .asaf-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 16px 20px;
        border-bottom: 1px solid rgba(255,255,255,0.06);
        background: linear-gradient(135deg, rgba(26,26,62,0.8) 0%, rgba(15,40,71,0.6) 50%, rgba(10,22,40,0.8) 100%);
        border-radius: 20px 20px 0 0;
      }

      .asaf-brand {
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 0;
      }

      .asaf-brand img {
        width: 38px;
        height: 38px;
        border-radius: 12px;
        border: 1px solid rgba(255,255,255,0.12);
        box-shadow: 0 4px 16px rgba(102,126,234,0.15);
      }

      .asaf-title {
        margin: 0;
        font-size: 15px;
        font-weight: 800;
        color: #f8fafc;
        letter-spacing: -0.02em;
      }

      .asaf-subtitle {
        margin: 2px 0 0;
        color: #94a3b8;
        font-size: 11px;
      }

      .asaf-close-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border-radius: 10px;
        border: 1px solid rgba(255,255,255,0.08);
        background: rgba(255,255,255,0.04);
        color: #94a3b8;
        font-size: 16px;
        cursor: pointer;
        transition: all 0.2s;
      }

      .asaf-close-btn:hover {
        background: rgba(255,255,255,0.1);
        color: #f8fafc;
      }

      .asaf-status-pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        border-radius: 999px;
        background: rgba(16,185,129,0.1);
        color: #6ee7b7;
        border: 1px solid rgba(16,185,129,0.2);
        padding: 5px 10px;
        font-size: 10px;
        font-weight: 700;
        white-space: nowrap;
        letter-spacing: 0.03em;
      }

      .asaf-status-dot {
        width: 6px;
        height: 6px;
        border-radius: 999px;
        background: #34d399;
        box-shadow: 0 0 6px rgba(52,211,153,0.4);
      }

      .asaf-section {
        padding: 16px 20px;
      }

      .asaf-stack {
        display: grid;
        gap: 12px;
      }

      .asaf-mode {
        border: 1px solid rgba(255,255,255,0.06);
        border-radius: 14px;
        background: rgba(255,255,255,0.03);
        padding: 14px;
      }

      .asaf-mode-title {
        margin: 0 0 10px;
        color: #94a3b8;
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.06em;
      }

      .asaf-radio-row {
        display: grid;
        gap: 8px;
        color: #cbd5e1;
        font-size: 12px;
        font-weight: 500;
      }

      .asaf-radio-row label {
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
      }

      .asaf-radio-row input {
        accent-color: #10b981;
      }

      .asaf-card {
        border-radius: 14px;
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(255,255,255,0.06);
        padding: 14px;
      }

      .asaf-card-title {
        margin: 0 0 8px;
        color: #64748b;
        font-size: 10px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.06em;
      }

      .asaf-card-body {
        margin: 0;
        color: #e2e8f0;
        font-size: 13px;
        line-height: 1.5;
        max-height: 118px;
        overflow: hidden;
        white-space: pre-wrap;
        word-break: break-word;
      }

      .asaf-card-body[data-loading="false"] {
        overflow: auto;
      }

      .asaf-image-box {
        display: grid;
        place-items: center;
        min-height: 140px;
        color: #e2e8f0;
      }

      .asaf-thumbnail {
        display: block;
        width: 100%;
        max-width: 220px;
        height: 124px;
        object-fit: cover;
        border-radius: 12px;
        border: 1px solid rgba(255,255,255,0.08);
      }

      .asaf-thumbnail-placeholder {
        display: grid;
        place-items: center;
        width: 100%;
        max-width: 220px;
        height: 124px;
        border: 1px dashed rgba(148,163,184,0.25);
        border-radius: 12px;
        color: #475569;
        font-size: 12px;
        background: rgba(255,255,255,0.02);
      }

      .asaf-spinner {
        display: inline-block;
        width: 14px;
        height: 14px;
        margin-right: 8px;
        vertical-align: -2px;
        border: 2px solid rgba(148,163,184,0.2);
        border-top-color: #34d399;
        border-radius: 999px;
        animation: asaf-spin 0.8s linear infinite;
      }

      @keyframes asaf-spin {
        to { transform: rotate(360deg); }
      }

      .asaf-button {
        width: 100%;
        border: 0;
        border-radius: 12px;
        background: linear-gradient(135deg, #10b981, #06b6d4);
        color: #022c22;
        cursor: pointer;
        font-size: 13px;
        font-weight: 700;
        padding: 12px 14px;
        pointer-events: auto;
        position: relative;
        z-index: 3;
        user-select: none;
        -webkit-user-select: none;
        touch-action: manipulation;
        box-shadow: 0 4px 20px rgba(16,185,129,0.2);
        transition: all 0.2s;
      }

      .asaf-button:hover { 
        box-shadow: 0 6px 28px rgba(16,185,129,0.35);
        transform: translateY(-1px);
      }

      .asaf-button:disabled {
        cursor: not-allowed;
        opacity: 0.55;
        transform: none;
      }

      .asaf-button-secondary {
        border: 1px solid rgba(248,113,113,0.25);
        background: rgba(127,29,29,0.2);
        color: #fecaca;
        box-shadow: none;
      }

      .asaf-button-secondary:hover {
        background: rgba(153,27,27,0.35);
        box-shadow: none;
        transform: none;
      }

      .asaf-actions {
        display: grid;
        grid-template-columns: 1.4fr 0.8fr;
        gap: 10px;
        position: relative;
        z-index: 2;
      }

      .asaf-footer {
        margin-top: 4px;
        border-radius: 12px;
        background: rgba(16,185,129,0.08);
        border: 1px solid rgba(16,185,129,0.15);
        color: #6ee7b7;
        padding: 12px;
        text-align: center;
        font-size: 12px;
        font-weight: 600;
      }

      .asaf-footer[data-type="error"] {
        background: rgba(239,68,68,0.08);
        border-color: rgba(239,68,68,0.2);
        color: #fca5a5;
      }

      .asaf-footer[data-type="muted"] {
        background: rgba(59,130,246,0.08);
        border-color: rgba(59,130,246,0.15);
        color: #93c5fd;
      }

      .asaf-footer[data-type="processing"] {
        background: rgba(245,158,11,0.08);
        border-color: rgba(245,158,11,0.15);
        color: #fcd34d;
      }

      .asaf-brand-foot {
        margin-top: 10px;
        text-align: center;
        color: #475569;
        font-size: 11px;
      }

      [hidden] { display: none !important; }
    </style>

    <section class="asaf-panel" data-asaf-panel>
      <header class="asaf-header">
        <div class="asaf-brand">
          <img alt="Autofillstock" src="${i.default}" />
          <div>
            <p class="asaf-title">AUTOFILLSTOCK</p>
            <p class="asaf-subtitle">${"shutterstock"===t?"Shutterstock":"Adobe Stock"} \xb7 Auto metadata</p>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px;">
          <span class="asaf-status-pill"><span class="asaf-status-dot"></span>ACTIVE</span>
        </div>
      </header>

      <div class="asaf-section">
        <div class="asaf-stack">
          <div class="asaf-mode">
            <p class="asaf-mode-title">Mode pengisian</p>
            <div class="asaf-radio-row">
              <label><input name="asaf-fill-mode" value="all" type="radio" checked /> Isi mulai dari awal</label>
              <label><input name="asaf-fill-mode" value="empty" type="radio" /> Isi yang kosong saja</label>
            </div>
          </div>

          <div class="asaf-card asaf-image-box">
            <img class="asaf-thumbnail" data-asaf-thumbnail alt="Thumbnail aset aktif" hidden />
            <div class="asaf-thumbnail-placeholder" data-asaf-thumbnail-placeholder>
              Thumbnail aset aktif
            </div>
          </div>

          <div class="asaf-card">
            <p class="asaf-card-title">Category</p>
            <p class="asaf-card-body" data-asaf-category-preview data-loading="false">-</p>
          </div>

          <div class="asaf-card">
            <p class="asaf-card-title">Title</p>
            <p class="asaf-card-body" data-asaf-title-preview data-loading="false">-</p>
          </div>

          <div class="asaf-card">
            <p class="asaf-card-title">Keywords</p>
            <p class="asaf-card-body" data-asaf-keyword-preview data-loading="false">-</p>
          </div>

          <div class="asaf-actions">
            <button class="asaf-button" data-asaf-generate type="button">\u26a1 Generate</button>
            <button class="asaf-button asaf-button-secondary" data-asaf-stop type="button">Stop</button>
          </div>

          <div class="asaf-footer" data-asaf-footer data-type="success">Siap generate metadata</div>
          <div class="asaf-brand-foot">autofillstock.my.id</div>
        </div>
      </div>
    </section>
  `,document.documentElement.appendChild(F);let r=a.querySelector("[data-asaf-close]"),n=a.querySelector("[data-asaf-backdrop]");function l(){x||(F.style.display="none")}r&&r.addEventListener("click",l),n&&n.addEventListener("click",l);let w=chrome.runtime?.onMessage;w&&w.addListener(e=>{e?.type==="ADOBESTOCK_PANEL_SYNC"&&(F.style.display="grid")}),a.querySelector("[data-asaf-panel]");let D=a.querySelector("[data-asaf-generate]"),v=a.querySelector("[data-asaf-stop]"),b=a.querySelector("[data-asaf-footer]"),y=!1,x=!1,z=T(),C=a.querySelector("[data-asaf-thumbnail]"),E=a.querySelector("[data-asaf-thumbnail-placeholder]");async function k(e,t,F){try{let a=await chrome.storage.local.get(["activation_code"]),r=a.activation_code;if(!r)return;await fetch("https://autofillstock.my.id/api/extension/log-generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({activationCode:r,platform:F,filename:t,title:e.title||e.description||""})})}catch(e){console.log("[autofillstock] Failed to log generate:",e)}}async function O(e){let t;let F=function(){if(g()){let e=document.querySelector(d.description),t=document.querySelector(d.category1),F=H(),a=Array.from(document.querySelectorAll("button")).filter(e=>e.textContent?.includes("+")).map(e=>e.textContent?.replace("+","").trim()||"").filter(e=>e.length>1&&e.length<32).slice(0,30).join(", "),r=e?.value||"",n=t?.textContent?.replace(/\u200B/g,"").trim()||"";return[F?`Original file name: ${F}`:"",a?`Keyword suggestions: ${a}`:"",`Available Shutterstock categories: ${c.join(", ")}`,n?`Current Shutterstock category: ${n}`:"",r?`Existing description: ${r}`:""].filter(Boolean).join("\n").trim()}let e=u(f.title),t=u(f.description),F=u(f.category),a=e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement?e.value:e?.textContent||"",r=t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement?t.value:t?.textContent||"",n=F instanceof HTMLSelectElement?F.selectedOptions[0]?.text||F.value:"",i=document.body.innerText||"",o=i.match(/Original name\(s\):\s*([^\n]+)/i)?.[1]?.trim()||"",s=Array.from(document.querySelectorAll("button")).filter(e=>e.textContent?.includes("+")).map(e=>e.textContent?.replace("+","").trim()||"").filter(e=>e.length>1&&e.length<32).slice(0,24).join(", ");return[o?`Original file name: ${o}`:"",s?`Keyword suggestions: ${s}`:"",n?`Current Adobe category: ${n}`:"",a?`Existing text: ${a}`:"",r?`Existing description: ${r}`:""].filter(Boolean).join("\n").trim()}(),r=g()?H()||document.title||"unknown":document.title||"unknown",n=p(e),i=await chrome.storage.local.get(["activation_code"]),l=i.activation_code||"";t=e.openai_api_key?await (0,o.generateMetadata)(e.openai_api_key,F):await (0,o.generateMetadataViaServer)(l,F,r,n);let A=(e.usage_count||0)+1;g()&&(t={...t,category:M(t)}),function(e,t){let F=e.querySelector("[data-asaf-title-preview]"),a=e.querySelector("[data-asaf-category-preview]"),r=e.querySelector("[data-asaf-keyword-preview]");a&&(a.textContent=t.category||"-",a.dataset.loading="false"),F&&(F.textContent=t.description||"-",F.dataset.loading="false"),r&&(r.textContent=t.keywords.join(", ")||"-",r.dataset.loading="false")}(a,t);let B=a.querySelector("[data-asaf-title-preview]"),w=a.querySelector("[data-asaf-keyword-preview]");return B&&(B.textContent=t.description||"-"),w&&(w.textContent=t.keywords.join(", ")||"-"),await (0,s.updateSettings)({usage_count:A,last_generated:new Date().toISOString()}),e.usage_count=A,await I(t),e.openai_api_key&&k(t,r,n),t}async function N(e){let t=0,r=!1,n="",i=p(e),o=S(),s=function(){let e=document.body.innerText||"",t=e.match(/Not submitted\s*\((\d+)\)/i)||e.match(/(?:Images|Videos)\s*\((\d+)\)/i),F=e.match(/File types:\s*All\s*\((\d+)\)/i),a=e.match(/Submit\s+(\d+)\s+files?/i);return Number(t?.[1]||F?.[1]||a?.[1]||0)}(),l=s||Math.max(o.length,1);if(y=!1,V(a,`Terdeteksi ${l}/${l} file`,"muted"),await X(500),0===o.length){R(a,1,1),await O(e),t=1,V(a,"1 file selesai","success"),await m(t,i);return}let f=S()[0];if(f&&!g()){V(a,"Mulai dari file pertama...","muted");let e=await G(f);if(!e){V(a,"Gagal memilih file pertama","error");return}await K(),await X(500)}else g()&&(V(a,"Memakai file aktif Shutterstock...","muted"),await K(),await X(500));for(let i=0;i<l&&!y&&i<50;i+=1){await K(),R(a,t+1,l);try{await O(e)}catch(F){let e=F instanceof Error?F.message:"Generate metadata gagal.";V(a,`File ${t+1} gagal: ${e}. Lanjut...`,"error"),await X(1500),t+=1;continue}if((t+=1)>=l){r=!0;break}if(y||await j(a,5e3),y)break;F.style.pointerEvents="none",await X(300);let i=S(),o=g()?i[t]:(()=>{let e=L(i),F=e?i.indexOf(e):t-1;return i[F+1]||i[t]})();if(!o){V(a,n=`File berikutnya tidak ditemukan setelah ${t}/${l}`,"error");break}let s=await G(o);if(F.style.pointerEvents="auto",!s){V(a,n=`Gagal pindah ke file ${t+1}/${l}`,"error");break}}r?V(a,`${t} file selesai`,"success"):!y&&n?V(a,n,"error"):y?V(a,`${t}/${l} file diproses`,"muted"):V(a,`${t}/${l} file diproses`,"error"),b&&(r?(b.textContent="Ready",b.dataset.type="success"):y&&(b.textContent="Stopped",b.dataset.type="muted")),!y&&r&&(function(e,t){let F=document.getElementById("adobestock-autofill-complete-modal");F&&F.remove();let a="shutterstock"===t?{title:"GENERATE SELESAI",message:`Sebanyak ${e} aset Shutterstock telah diproses. Cek metadata, lalu klik Save atau Submit jika sudah siap.`}:{title:"GENERATE SELESAI",message:`Sebanyak ${e} aset telah diproses. Jangan lupa tekan tombol SAVE WORK di kiri bawah.`},r=document.createElement("div");r.id="adobestock-autofill-complete-modal",r.style.position="fixed",r.style.inset="0",r.style.zIndex="2147483647",r.style.display="grid",r.style.placeItems="center",r.style.background="rgba(0, 0, 0, 0.6)",r.style.backdropFilter="blur(8px)",r.style.fontFamily='Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',r.innerHTML=`
    <div style="
      width: min(420px, calc(100vw - 32px));
      border-radius: 20px;
      background: rgba(13, 17, 23, 0.65);
      backdrop-filter: blur(40px) saturate(1.2);
      -webkit-backdrop-filter: blur(40px) saturate(1.2);
      color: #e2e8f0;
      border: 1px solid rgba(255,255,255,0.12);
      padding: 36px 28px 28px;
      text-align: center;
      box-shadow: 0 24px 80px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255,255,255,0.04) inset;
      font-family: Inter, ui-sans-serif, system-ui, sans-serif;
    ">
      <div style="
        width: 56px; height: 56px; margin: 0 auto 18px;
        border-radius: 16px;
        background: linear-gradient(135deg, rgba(16,185,129,0.15), rgba(6,182,212,0.15));
        border: 1px solid rgba(16,185,129,0.25);
        display: grid; place-items: center;
        font-size: 28px; color: #34d399;
      ">\u2713</div>
      <div style="font-size: 16px; font-weight: 700; margin-bottom: 12px; color: #f8fafc;">
        ${a.title}
      </div>
      <div style="font-size: 14px; line-height: 1.6; color: #94a3b8;">
        ${a.message||""}
      </div>
      <div style="margin-top: 18px; font-size: 11px; color: #475569;">autofillstock.my.id</div>
    </div>
  `,r.addEventListener("click",e=>{e.target===r&&r.remove()}),document.documentElement.appendChild(r)}(t,i),await m(t,i))}async function Q(){if(!x){x=!0,V(a,"Memulai generate...","muted"),Z(a,!0);try{let e=await (0,s.getSettings)();if(!e.activation_status)throw Error("Extension belum aktif. Buka popup extension untuk aktivasi.");await N(e)}catch(t){let e=t instanceof Error?t.message:"Generate metadata gagal.";V(a,e,"error"),console.error("[autofillstock] generate error:",t)}finally{x=!1,Z(a,!1)}}}if(z&&C&&(C.src=z,C.hidden=!1,E&&(E.hidden=!0)),D)for(let e of(D.disabled=!1,D.onclick=Q,["pointerdown","mousedown","touchstart","click"]))D.addEventListener(e,e=>{e.preventDefault(),e.stopPropagation(),Q()},{capture:!0});a.addEventListener("pointerdown",e=>{let t=e.composedPath().some(e=>e instanceof HTMLElement&&e.hasAttribute("data-asaf-generate"));t&&(e.preventDefault(),e.stopPropagation(),Q())},!0),v?.addEventListener("click",()=>{y=!0,b&&(b.textContent="Stopping...",b.dataset.type="muted"),V(a,"Stopping...","muted")}),e.panel_enabled||h()}(e):h()}U();let J=new MutationObserver(()=>{window.clearTimeout(a),a=window.setTimeout(U,400)});J.observe(document.documentElement,{childList:!0,subtree:!0}),chrome.storage?.onChanged?.addListener((e,t)=>{"local"===t&&(e.panel_enabled||e.selected_microstock)&&U()}),chrome.runtime.onMessage.addListener((e,t,F)=>e?.type==="ADOBESTOCK_PANEL_SYNC"?(U().then(()=>F({ok:!0})).catch(e=>F({ok:!1,error:e instanceof Error?e.message:"Sync panel gagal."})),!0):e?.type==="ADOBESTOCK_AUTOFILL_METADATA"&&(I(e.payload).then(e=>F({ok:!0,results:e})).catch(e=>F({ok:!1,error:e instanceof Error?e.message:"Auto-fill gagal."})),!0))},{"data-base64:~assets/icon.png":"ewwWA","~/lib/openai":"dz0fj","~/lib/storage":"jsYik","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],ewwWA:[function(e,t,F){t.exports="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAADiJSURBVHja7NbtWkxRGIDhDkQf0%2BQ8nEtGMpIkyUg7SZJwViQZGUkqU5KMDmK5xtjXO7tZa%2FZa8%2FXnfX48x3A%2FfdnR8yuXR8%2Bj5lX8y4WXTe0s2VgPGq922tnyrk5ab8K34%2FAmO1XZ3VQ5ynS9wygz3aNmbO13ttnQ9sKba7VddwV7g8HtSPNdbCGu1L0Wfdpuv6V2Kvq3HF5%2FalvJVnrQan2bnWmt1TbcrbdX33%2FkTUNX4%2F74l7NVcXetYkZS%2B51sLLQzM3I9sPFqv9K7cbFTd3l72fzPxm4260Sa8O2Hyd4KbDLu2L%2Fbto7cTR2Z4dTKye6E9t0MT7fQ3bhD%2F2ZsHbi7d2Ayqe0nmw3tm8ncD2yu2l56Dy721V3B3lBht7GHzfoizfu2Y4YeBbYQ99m%2FyFbJ3WLJDKb2Kdnj0LbN4FILPYn76N%2ByraK7p0UzkNqHZCuhbZmBZ4Gt1vfe3XOfNmut2eu39aK%2Bd%2B7Wfdqo9dLevwEAf%2FAHf%2FAHf%2FAHfzX4ywCAP%2FiDP%2FiDP%2FiDvxr8ZQDAH%2FzBH%2FzBH%2FzBXw3%2BMgDgD%2F7gD%2F7gD%2F7grwZ%2FGQDwB3%2FwB3%2FwB3%2FwV4O%2FDAD4gz%2F4gz%2F4gz%2F4q8FfBgD8wR%2F8wR%2F8wR%2F8FeAf9%2BptdQAqEfiDP%2FiDP%2FiDP%2FirwV8GAPzBH%2FzBH%2FzBH%2FzV4C8DAP7gD%2F7gD%2F7gD%2F5q8JcBAH%2FwB3%2FwB3%2FwB381%2BMsAgD%2F4gz%2F4gz%2F4g78a%2FGUAwB%2F8wR%2F8wR%2F8wV8N%2FjIA4A%2F%2B4A%2F%2B4A%2F%2B4K8GfxkA8Ad%2F8Ad%2F8Ad%2F8FeDvwwA%2BIM%2F%2BIM%2F%2BIM%2F%2BKvBXwYA%2FMEf%2FMEf%2FMEf%2FPXgfykeAPAHf%2FAHf%2FAHf%2FDXgn88ALlKBP7gD%2F7gD%2F7gD%2F5q8JcBAH%2FwB3%2FwB3%2FwB38F%2BMe9flMbAPAHf%2FAHf%2FAHf%2FBXg78MAPiDP%2FiDP%2FiDP%2FirwV8GAPzBH%2FzBH%2FzBH%2FzV4C8DAP7gD%2F7gD%2F7gD%2F5q8JcBAH%2FwB3%2FwB3%2FwB381%2BMsAgD%2F4gz%2F4gz%2F4g78a%2FGUAwB%2F8wR%2F8wR%2F8wV8N%2FjIA4A%2F%2B4A%2F%2B4P%2BX%2FXpHrSoMozDsOLS0dj7OQETUGcjurbwrdg7A1tJLvAzARvACUULUgBBTxGjMNodztgtSiMEUR9bzwWr%2BCTzvD3%2F41%2BCfAIA%2F%2FOEPf%2FjDH%2F41%2BCcA4A9%2F%2BMMf%2FvCHfw3%2BCQD4wx%2F%2B8Ic%2F%2FOHfgH927OR%2BAMAf%2FvCHP%2FzhD%2F8C%2FKddWQQA%2FOEPf%2FjDH%2F7wb8F%2FtufzAIA%2F%2FOEPf%2FjDH%2F41%2BCcA4A9%2F%2BMMf%2FvCHfw3%2BCQD4wx%2F%2B8Ic%2F%2FOFfg38CAP7whz%2F84Q9%2F%2BNfgnwCAP%2FzhD3%2F4wx%2F%2BNfgnAOAPf%2FjDH%2F7wh38J%2FgmA9QH%2B8Ic%2F%2FOEPf%2FjX4J8AgD%2F84Q9%2F%2BMMf%2FjX4JwDgD3%2F4wx%2F%2B8Id%2FDf4JAPjDH%2F7whz%2F84d%2BBfwLgzPoAf%2FjDH%2F7whz%2F8a%2FBPAMAf%2FvCHP%2FzhD%2F8C%2FKddfTYPAPjDH%2F7whz%2F84V%2BDfwIA%2FvCHP%2FzhD3%2F41%2BCfAIA%2F%2FOEPf%2FjDH%2F41%2BCcA4A9%2F%2BMMf%2FvCHfw%2F%2BJ6YAgD%2F84Q9%2F%2BMMf%2FjX4JwDgD3%2F4wx%2F%2B8Id%2FDf4JAPjDH%2F7whz%2F84V%2BDfwIA%2FvCHP%2FzhD3%2F41%2BCfAIA%2F%2FOEPf%2FjDH%2F41%2BCcA4A9%2F%2BMMf%2FvCHfw3%2BCQD4wx%2F%2B8Ic%2F%2FOFfg38CAP7whz%2F84Q9%2F%2BNfgnwCAP%2FzhD3%2F4wx%2F%2BBfhPu%2FZ0HgDwhz%2F84Q9%2F%2BMO%2FBv8EAPzhD3%2F4wx%2F%2B8K%2FBPwEAf%2FjDH%2F7whz%2F8a%2FBPAMAf%2FvCHP%2FzhD%2F8a%2FBMA8Ic%2F%2FOEPf%2FjDvwb%2FBAD84Q9%2F%2BMMf%2FvCvwT8BAH%2F4wx%2F%2B8Ic%2F%2FGvwTwDAH%2F7whz%2F84Q%2F%2FGvwTAPCHP%2FzhD3%2F4w78G%2FwQA%2FOEPf%2FjDH%2F7w78A%2FAXB2fYA%2F%2FOEPf%2FjDH%2F4l%2BCcA1gb4wx%2F%2B8Ic%2F%2FOFfg38CAP7whz%2F84Q9%2F%2BBfgP%2B36IgDgD3%2F4wx%2F%2B8Id%2FDf4JAPjDH%2F7whz%2F84d%2BA%2F7SVeQDAH%2F7whz%2F84Q%2F%2FGvwTAPCHP%2FzhD3%2F4w78G%2FwQA%2FOEPf%2FjDH%2F7wr8E%2FAQB%2F%2BMMf%2FvCHP%2Fxr8E8AwB%2F%2B8Ic%2F%2FOEP%2Fxr8EwDwhz%2F84Q9%2F%2BMO%2FBv8EAPzhD3%2F4wx%2F%2B8K%2FBPwEAf%2FjDH%2F7whz%2F8a%2FBPAMAf%2FvCHP%2FzhD%2F8a%2FBMA8Ic%2F%2FOEPf%2FjDvwb%2FBAD84Q9%2F%2BMMf%2FvAvwH%2FajUUAwB%2F%2B8Ic%2F%2FOEP%2Fxr8EwDwhz%2F84Q9%2F%2BMO%2FBv8EAPzhD3%2F4wx%2F%2B8K%2FBPwEAf%2FjDH%2F7whz%2F8a%2FBPAMAf%2FvCHP%2FzhD%2F8G%2FKc92Q%2BAc2sD%2FOEPf%2FjDH%2F7wr8E%2FAQB%2F%2BMMf%2FvCHP%2Fxr8E8AwB%2F%2B8Ic%2F%2FOEP%2Fxr8EwDwhz%2F84Q9%2F%2BMO%2FBv8EAPzhD3%2F4wx%2F%2B8K%2FBPwEAf%2FjDH%2F7whz%2F8S%2FBPAHwY4A9%2F%2BMMf%2FvCHfwH%2B024uAgD%2B8Ic%2F%2FOEPf%2Fj34H98CgD4wx%2F%2B8Ic%2F%2FOFfg38CAP7whz%2F84Q9%2F%2BNfgnwCAP%2FzhD3%2F4wx%2F%2BNfgnAOAPf%2FjDH%2F7wh38N%2FgkA%2BMMf%2FvCHP%2FzhX4N%2FAgD%2B8Ic%2F%2FOEPf%2FjX4J8AgD%2F84Q9%2F%2BMMf%2FjX4JwDgD3%2F4wx%2F%2B8Id%2FA%2F7THs8DAP7whz%2F84Q9%2F%2BNfgnwCAP%2FzhD3%2F4wx%2F%2BNfgnAOAPf%2FjDH%2F7wh38N%2FgkA%2BMMf%2FvCHP%2FzhX4D%2FtFuLAIA%2F%2FOEPf%2FjDH%2F4t%2BE8BcP7DAH%2F4wx%2F%2B8Ic%2F%2FGvwTwDAH%2F7whz%2F84Q%2F%2FGvwTAPCHP%2FzhD3%2F4w78G%2FwQA%2FOEPf%2FjDH%2F7wr8E%2FAQB%2F%2BMMf%2FvCHP%2Fxr8E8AwB%2F%2B8Ic%2F%2FOEP%2Fxr8EwDwhz%2F84Q9%2F%2BMO%2FBv8EAPzhD3%2F4wx%2F%2B8K%2FBPwEAf%2FjDH%2F7whz%2F8a%2FBPAMAf%2FvCHP%2FzhD%2F8S%2FBMAqwP84Q9%2F%2BMMf%2FvBvwH%2Fao3kAwB%2F%2B8Ic%2F%2FOEP%2Fx78j99eBAD84Q9%2F%2BMMf%2FvCvwT8BAH%2F4wx%2F%2B8Ic%2F%2FGvwTwDAH%2F7whz%2F84Q%2F%2FGvwTAPCHP%2FzhD3%2F4w78G%2FwQA%2FOEPf%2FjDH%2F7wr8E%2FAQB%2F%2BMMf%2FvCHP%2Fxr8E8AwB%2F%2B8Ic%2F%2FOEP%2Fxr8EwDwhz%2F84Q9%2F%2BMO%2FBv8EAPzhD3%2F4wx%2F%2B8K%2FBPwEAf%2FjDH%2F7whz%2F8a%2FBPAMAf%2FvCHP%2FzhD%2F8O%2FBMAF1cH%2BMMf%2Fv8H%2FqfvvR0vPVj7vQv338Mf%2FvCHf2A%2FbADAH%2F7wX178Z9C%2F3vg27v7cG3O5vf3ntc3v490XG%2FCHP%2Fzh%2F3e7swgA%2BMMf%2FsuH%2F%2Bx3v7m9Ox7mdnb3xqsrH%2BEPf%2FjD%2F0%2F4JwDgD3%2F4Lxf%2BD998Hf%2FlXn3aHk9dfgl%2F%2BMMf%2Fgfwn%2FZwHgDwhz%2F8lwf%2FGd5HcZ%2B3fswiAP7whz%2F8D%2BKfAIA%2F%2FOG%2FHPivvNsaj%2FJWv%2BzAH%2F7wh%2F8v9u79t8rDvuP4v9FqbaMSjNpSqan5YUTalPywDWlNkLam0rZWmgKa2l82OnVj0gKSO9qk2NwMAcydEJyR4DSNURKbNKkJYJuLr%2FiGDfiKwRBsYwzHl3Oep3547HzhYONz%2FFy%2Bz%2BV9pM8PkSKdH0C8Pl%2F7%2BT7fdPylAIA%2F%2BIO%2FPv6%2F%2BrDXNEz3PyUNg%2BAP%2FuAP%2Fjb86QUA%2FMEf%2FLXwl4yOp0wvPtbywD%2B9fRX8wR%2F8wf%2FJAgD%2B4A%2F%2BuvhbK3xefm6OTJhLftcA%2FuAP%2FuD%2FeAEAf%2FAHfz38l7x%2Bybw%2FkfKIfnlXwMHzt8Ef%2FMEf%2FB8vAOAP%2FuDvN%2F6SX5f1m4bp%2FWdsMmX%2BrPgq%2BIM%2F%2BIO%2FFADwB3%2Fw9xt%2Fmf6tH897%2B5GXBPUMjZvLtjaBP%2FiDf7zxlwIA%2FuAP%2Fn7iL%2FnNyf6HMPvxmUga5oOJlHny8jD4gz%2F4xxt%2FKQDgD%2F7g7z%2F%2Byza3mEMPkr4XACvry%2FrAH%2FzBP774SwEAf%2FAHf7%2FwlxRV3rIwVikAVvF4cXcr%2BIM%2F%2BMcLf8ne6QIA%2FuAP%2Fn7iL9O%2FhfHYZMrnAmCntu%2B%2BuWRjA%2FiDP%2FjHD38pAOAP%2FuDvD%2F7p07%2BVxFRMX7YAZgqApKhqAPzBH%2Fzjh78UAPAHf%2FD3D%2F8Ve9qfgDhlGJ7ib5imfF9afnKkHfzBH%2FzjhL8UgM488Ad%2F8Pcaf8mJpuEnEJ7w%2BDmAyZQxZwGwVgO%2Fv6kR%2FMEf%2FOODvxQA8Ad%2F8HcH%2F%2Bynf4lhePnjf%2Fme2XKieQj8wR%2F8Y4C%2F5HO7AIA%2F%2BIO%2F5%2FinT%2F%2B%2B%2FRQgKdP%2FU%2FPLD7vAH%2FzBPx74SwEAf%2FAHf%2B%2FxX32sKx1dz58FMOaf%2Fh9fDSxqAX%2FwB%2F%2Fo4y8FAPzBH%2Fw9wl9ird3Ni3BiCmvD%2Fd%2F9Z5yq7ntmTn4D%2BIM%2F%2BEcbfykA4A%2F%2B4O8Mf%2BfTv2Q8abg2%2FSdk%2Bs84BRX94A%2F%2B4B9t%2FKUAgD%2F4g78D%2FJ1P%2F%2BmxJndfp%2F%2F0vPJ2O%2FiDP%2FhHFH8pAP%2FZmQf%2B4A%2F%2B3uH%2FPyd6swY4IVsBPk7%2Fko4vE%2BbSzY3gD%2F7gHz38pQB8e6oAgD%2F4g783%2BC95vdHas88WYHlFsLPX%2FjpKSeMd8Ad%2F8I8W%2FpJ90wUA%2FMEf%2FN3DX9Jgrv%2BkL0t4na8GGobpEH%2FJmtIu8Ad%2F8I8g%2Fl%2BfKQDgD%2F7g7z7%2BS96Q6d9JUobh8%2FQvGbg3YT6%2Fswn8wR%2F8o4W%2FFADwB3%2Fwdxf%2FZzY0mAV%2FuuEUYFkN9Hf6T18NBH%2FwB%2F9o4S8FAPzBH%2FzdxX%2FZluaZc79ZxPlq4LhM%2F66m4FQ%2F%2BIM%2F%2BEcHfykA4A%2F%2B4O8W%2Fnbk3K97Sc6zGpiS6d%2F1DCWS5srDbeAP%2FuAfDfylAIA%2F%2BIO%2FG%2Fg7mP4drAZ6Of2nrwbmFNSDP%2FiDf%2FjxlwIA%2FuAP%2Fk7xlxTX3HEfYFkNdDD9O09x3W3wB3%2FwDz%2F%2BUgDAH%2FzB3x38V%2By5vBBYHb8lcGxSpn%2Bv84sProE%2F%2BIN%2FuPGXAgD%2B4A%2F%2BDvCXWHf1fUE4ZWR97tfV1cDc7Y3gD%2F7gH0L8JZ%2FZBQD8wR%2F8HeDvYPp3vBoo5359TcW1u%2BAP%2FuAfXvylAIA%2F%2BIP%2FQvGXnLx811eEJ5KGTP8K2fB5H%2FiDP%2FiHE38pAOAP%2FuDvDP%2FVxzp9B9jaNDjTOaJWAIYSk%2BbKt9rAH%2FzBP3z4SwEAf%2FAH%2FwXgL5Fzvz6mqGrAXLbtkrxuWCHNAw%2FMnE114A%2F%2B4B8O%2FCX7pwsA%2BIM%2F%2BGeLv%2F70b%2BH%2FzG%2FrzJ%2F9%2FxUF%2FCUHLw6AP%2FiDf7jwlwIA%2FuAP%2Ftnirz%2F9W%2Fg%2FY93rn4r135olYFXJFfAHf%2FAPD%2F5SAMAf%2FMF%2FIfjLuV%2B%2F1%2FCs6d%2FG305OfoPZfPOBWgHoGR43c3c0gj%2F4g3848JcCAP7gD%2F7Z4p927tfHrC%2FrNQV%2FyYr9bfIKYoWUtw%2BDP%2FiDfzjwlwIA%2FuAP%2Fpngrz%2F9W4VjSX6DwJ%2BWdeW9CvhL1n3aA%2F7gD%2F7Bx18KAPiDP%2FhnhL%2F%2B9F%2FeK%2BDPkYqrd1VXA1%2Fc1wT%2B4A%2F%2BwcZfCgD4gz%2F4Z4K%2F43O%2Fzq%2FxyfQ%2FR2rN3MJG6zkBxdXA%2B2bO5lrwB3%2FwDy7%2BUgDAH%2FzBfz78nZ77dZ5Vx6%2FOh%2F9MrP9XAX9J0bmb4A%2F%2B4B9c%2FKUAgD%2F4g78AH8Tpv7ZvNBP8JW%2FUWqd7VUvAK8Vt4A%2F%2B4B9M%2FKUAgD%2F4g3%2BYp%2F90%2FO3kFNQrrwaOmbk7G8Af%2FME%2FaPhLAbiaB%2F7gD%2F6ZpaRhUGP6zxJ%2FycrDbeZQQm81sLR1EPzBH%2FwDhr8UgF9dzQN%2F8Af%2F9Oid%2B02Ptd%2BfPf6SglP9qr8KWFvWBf7gD%2F4BwV%2FyR7sAgD%2F4g%2F%2F8OdE85P8E3TLkAH9JxTX11UDwB3%2FwDxD%2BXz8wXQDAH%2FzBP7DTvwP8Jc%2FvalJdDazqGTFzttSCP%2FiDfzDwlwIA%2FuAP%2Fk%2FPqasjKtO%2Fc%2Fwlv%2FjgmgL%2BksLKfvAHf%2FAPBv5SAMAf%2FMF%2F7qx%2BV%2Bfc7%2FM7m13BX1Kjvxr4Tiv4gz%2F46%2BMvBQD8wR%2F858hv1M79uoy%2FfaZ36dZ6642CagXA%2Bu6l22vBH%2FzBXxd%2FKQDgD%2F7gPxv%2BetN%2FbuEll%2FGXrHyrTQF%2FSUnTl%2BAP%2FuCvi78UAPAHf%2FB%2FEv8lv2uUF%2BkoTP%2Fu4y8pOHVdtQSs%2Bega%2BIM%2F%2BOvhLwUA%2FMEf%2FB%2FF3876Mp1zv0s3N3qEvyRnU51Z1T2iuhq4fE8D%2BIM%2F%2BOvgLwUA%2FMEf%2FAV%2Fe%2Fpv0Dj3a93z9xh%2FyfO7LlkQq5WAyp4R8Ad%2F8NfBXwoA%2BIM%2F%2BNvw26nXmv6tc78%2B4C9Zc6JTAX9J%2Fuk%2B8Ad%2F8PcffykA4A%2F%2B4C%2F4f7%2Fgktb07yP%2BkpKmO6ol4OWjLeAP%2FuDvL%2F5SAMAf%2FMHfxt9KUdWA7whaDxvm5Nf7hb9kY425dFu92TM8rrcaeCdhfm9HLfiDP%2Fj7h78UAPAHf%2FC38V%2B2tUnr3K8C%2FpJXinVXA4sbboE%2F%2BIO%2F9%2FhLDk4XAPAHf%2FCX6V%2Fh3K8K%2FpKLD1N4Vvdq4M9LO8Af%2FMHfF%2FytfGoXAPAHf%2FBXnf6V8beTs7lWdTVwYHTCXL63HvzBH%2Fy9x18KAPiDf2zxl6ic%2B63qvqePv8Q626u6GljROQz%2B4A%2F%2B3uMvBQD8wT%2Fu%2BK%2FY26Z07rc1IPhL1pZ1qf4qYENFD%2FiDP%2Fh7i78UAPAH%2F%2Fjhrz%2F9l7YMBgV%2FSb6d0tZBnQIwab8l8OXiZvAHf%2FD3Dn8pAOAP%2FrHEX3%2F6Dxj%2BktydDWbP8JjP%2BEuabt03FxdeBH%2FwB39v8JcCAP7gHzv8JSrnfksa7wQUf8lP32v3H3%2BJtRoI%2FuAP%2Ft7gLwUA%2FME%2Frvivfveazrnf7Y0Bxl9SdO6mAv6SVz9oB3%2FwB3%2F38ZcCAP7gHx%2F89af%2FouqBgOMvydlSazYP3PcZf4n1a4gf7q4Ff%2FAHf3fxlwIA%2FuAfE%2Fz1p%2F%2BETP9Bxl9yYWo1UK4G%2Boa%2FxFoNBH%2FwB3938Jccmi4A4A%2F%2BccPfOvfbcTuhMf2HCX87BRfMdX%2FsVsBfsu6zLvAHf%2FB3D38pAOAP%2FjHCX%2Ffcb0F9yPCXVHTeVcBfVgP%2F7sgl8Ad%2F8HcBfykA%2F301D%2FzBPxb4y%2FSvde43hPhLcnfWy2qgX%2FinrwZuvwD%2B4A%2F%2BzvGXAgD%2B4B8L%2FPWn%2F5DiL3n19x0K%2BEt2X%2BgHf%2FAHfwf4S07aBQD8wT%2Fy%2BMvBH63pP%2FT4f3M6B2sGFPCX%2FMv7beAP%2FuDvDH8pAOAP%2FhHGX%2F%2Fc7%2FVRmf5Di79k8dYas2ngvgb%2BshpYVAv%2B4A%2F%2BC8dfCgD4g3%2Bk8dc%2F9xsR%2FCUvH22R1UDf8JeUtt0Bf%2FAH%2F4XiLwWgIw%2F8wT%2By%2BOtP%2F1HBX7LJzoaKHgX8JWs%2FvQb%2B4A%2F%2BC8NfCgD4g3%2FU8X9xd6vW9B85%2FCXnrZf0KOAvq4EvHK4Hf%2FAH%2F%2BzxlwIA%2FuAfQfwlv9U591vePhxp%2FK0s31tvDoxO%2BIy%2FpKb%2Fnrl4x3nwB3%2Fwzw5%2FKQDgD%2F5Rxn%2FFPqVzvwdaI4y%2F5OelHQr4S7ZV94E%2F%2BIN%2FZvhLDk8XAPAH%2F2jirzf9l7YMRh9%2FiXW6V1BWyI%2FfawZ%2F8Af%2FzPGXAgD%2B4B9V%2FFceatea%2FmOAv2Rx4UWz484DtQLQc3fM%2FO6uC%2BAP%2FuCfGf5SAMAf%2FKOFv0Tj3G9x3e044C%2FZbOfl4mZBWSGll78Ef%2FAH%2F8zwlwIA%2FuAfRfxXv6d27jdm%2BEvyz%2FSploD%2FKOsAf%2FAH%2F%2FnxlwIA%2FuAfDfwVp3859xtT%2FCWVPSMK%2BMtq4PIDteAP%2FuD%2FdPylAIA%2F%2BEcGf%2F3pP6b4S5bvs1cDtUpAZe9d89kd58Af%2FMH%2FKfh%2F7XC5XQDAH%2FyjhP%2BSjTrnfgvP3Ig5%2FpI1H18RlBWysbIH%2FMEf%2FOfGXwoA%2BIN%2F%2BPGXrC%2Fr1Tr3C%2F4Pc%2B5hSppvq5aAl45dAn%2FwB%2F%2FZ8ZcCAP7gH1L89ad%2FOfcL%2FoL%2Fw0t939upuxpoffd3d58Hf%2FAHf8H%2FyQIA%2FuAfZvwldZrTP%2Fh%2Fhb%2Fkx%2B%2B2CMoKOXppAPzBH%2FwF%2FycLAPiDfxTwX7btksrBn7Ufd4O%2F4P9EtlVf110NLO8Af%2FAH%2F%2FS8NV0AwB%2F8Q46%2FFa1zv%2BAv%2BM%2BaxdsvWE%2FmqxWAgdFxc%2FnBGvAHf%2FAX%2FKUAgD%2F4hxh%2F1el%2F1fEr4C%2F4z5kXDjVYO%2FpqJaCiawj8wR%2F8BX8pAOAP%2FiHFX3v6B3%2FBf96s%2BUR7NbAb%2FMEf%2FNMLAPiDf4jxt8796kz%2FJVfAf0tWsd7Xr%2FqWwJeONYI%2F%2BIP%2FowUA%2FME%2FdPhLtM79gn%2BW%2BFvnen%2B4p8a63Ke6Gvjsm9XgD%2F5xxl8KwBToeeAP%2FqHDX6Z%2FpXO%2FLeCfHf4zsW73K68G3gR%2F8I87%2FlIAwB%2F8Q4W%2F%2FvQP%2FgvCX7L7Yr9qCXi1tBX8wT%2BW%2BEvK7AIA%2FuAfRvx%2FcqRda%2FoH%2FwXhL1m847xZ039PdTXwuf3nwR%2F844q%2FFADwB%2F%2Fw4C%2Bp7Rv1Hf%2BDFwfA3xH%2BkhcO1%2BuuBnYPgT%2F4xxV%2FKQDgD%2F5hw3%2F1e1d9x9%2FCKndHI%2Fg7xl%2Fy2uedgrJCXqu4Cv7gHyf8JUemCwD4g3%2Fw8def%2Fouqb4K%2Fi%2Fh%2FYzrlVwZVVwP%2F5p068Af%2FuOEvBQD8wT9M%2BP%2BytEtr%2Bgd%2F1%2FCXPLf3oupqYNOtUXPRzirwB%2F844S8FAPzBPyz4L8nXOfe74fM%2B8PcA%2F5lTva%2BWtgnKCjlQ3w%2F%2B4B8n%2FKUAgD%2F4Bxh%2Fyet15rpyhXO%2Fw%2BNmzqY68PcEf8mBuhuqJeCfP2gGf%2FCPC%2F5SAMAf%2FMOAf47S9L%2FuZA%2F4e4a%2F5Nkd56wfx6sVgO67CfO5A%2BfAH%2FzjgL8UAPAH%2F6Dj%2F62pbPjsutb0D%2F6e4i%2F526O6VwPLrt0Bf%2FCPA%2F5SAMAf%2FIOOf26hzrnfNSc6wd8X%2FCX%2F90WX9mog%2BIN%2FtPGXAnA5D%2FzBP7D429E69wv%2BfuIvse73q64G%2FvXbNeAP%2FlHGXwoA%2BIN%2FIPGX6V%2Fr3C%2F4%2B4q%2F5Ll9F63X9aqVgJobI%2BaiXZXgD%2F5RxV8KAPiDf%2BDw15%2F%2Bwd9f%2FCWFViqtgz2CskJ21fSBP%2FhHDn%2FJJ3YBAH%2FwDyr%2BK%2FbrnPv96bEO8NfDfybW6V7VEvCP7zeCP%2FhHEv%2BvvT1dAMAf%2FIOFv6S0ReXcL%2Fir4i959s1qs%2BPOA9XVwO%2FsqQJ%2F8I8a%2FlIAwB%2F8A4G%2F9vQv537BXx1%2FyUvHGlVXAz9svw3%2B4B81%2FKUAgD%2F4q%2BMfnOkf%2FAODv2RjZbegrJB%2F%2F%2FQy%2BIN%2FlPCXAgD%2B4B80%2FFcdVzn3a03%2F4B8o%2FCWVvXd1VwOPXgR%2F8I8K%2FlIAwB%2F8g4C%2FZP5zv2OTdsaThjnhUs733jMLTl03C75wM312Ts%2BefCc5k0l67Zz1JhsfTWXPAtKdcYpqrpuj40lzImW4Huvv0VgyZWXOElDZN2wu2n0W%2FME%2FCvhLAQB%2F8FfBP6vp38Y%2BmTJMw3T%2FY0wlMSnfFfhMxjDThc%2BPT9Kwi0H692%2Bs7gJ%2F8I8C%2FlIAwB%2F8FfDPYPqXaT%2Fl8b%2F7kykD%2FEMS68%2FKr4%2F1VWNJ4%2FHVwN83gD%2F4hx1%2FKQDgD%2F5BwX%2FtRz2PYTfh8cQn0z%2F4hyWJqRg%2BdQApiFIC2gfvm9%2FZWwX%2B4B9m%2FKUAgD%2F46%2BOffu7Xt0nPKhngH6rYv6v3%2B5M0pAQcbxsAf%2FAPK%2F5SAKZgzwN%2F8NfDX7KuvNenyV8%2B1iT5YBL8w5iJlKFTAmQ1EPzBP6z4SwEAf%2FDXxj8nv%2F6r6X9s0jCnPkz%2F4D9vUob%2FJWDm4cCB%2B%2BPmXx45D%2F7gH0b8pQCAP%2Fhr4C%2BpNQsq%2Br8CL2WYTP%2Fgn%2FnzAL7RL39vErIaCP7gHyb8JUenCwD4g78m%2FrmFjda5X%2FnRv0%2Bf8aQB%2FqwGOn4ocGN1J%2FiDf9jwlwIA%2FuCvhL%2BVx879Jg3Dr%2FUu8I9M5O%2BNj%2BuB8pbAsUnzR8frwB%2F8Q4O%2FnY%2FtAgD%2B4K%2BBf%2Fr0n5iKwfQP6CFZDUwkU4%2BtBi4qOgP%2B4B8W%2FKUAgD%2F4a%2BBvpbju9qMv%2FGH6B%2FPQrAaOp70g6GjzDfAH%2F7DgLwUA%2FMFfA%2F8V%2B1ufeNWvH5%2BxSfDnLYGubQM8ln8rbwF%2F8A8D%2FlIAwB%2F8fcNfYp3e9f2tf8mUAf6sBnpUAOzVwB8cqgZ%2F8A86%2FlIAwB%2F8%2FcZ%2FxYHW2Y79%2BDD9gz%2BrgV4UAMmfegbBH%2FyDjr8UAPAHfx%2Fwl7xRa5a3D8924tfr6R%2F8Y5KJpOHrMwDp%2BfXZa%2BAP%2FkHGXwoA%2BIO%2Fj%2FjPee434WEBMB5O%2F%2BDPaqB7n7HkbN8rq4F%2FX1IH%2FuAfVPylAIA%2F%2BPuDv53a66NzopgyPHtxC%2FizGuj2WySfmqbb98xv7zkN%2FuAfRPylAIA%2F%2BHuP%2F5zTv6cPAsq5X%2FBnNdD1NwHOm%2F2NfeAP%2FsHDXwpAax74g7%2B3%2BGc0%2FcvLgAzX%2F7EGf1YD3S2Uycy%2F%2F18%2FbgJ%2F8A8a%2FlIAwB%2F8fcD%2F0XO%2FvvwUQKZ%2F8Gc10O%2FpX9I9kjB%2FcLgK%2FME%2FCPhLiqcLAPiDv9f45xTIud9MkkwZbp37BX%2Fy8FcBhns3ALJOWeeX4A%2F%2BQcJfCgD4g7%2F7%2BGc8%2FXvyQKA8qAX%2BxM5EynDnDPAC87%2BnO8Af%2FIOCvxQA8Ad%2Fd%2FF3Mv1LEvZ1QCfTP%2FgTV94SmHKEv6wG%2FtU758Ef%2FIOAvxQA8Ad%2F9%2FGXFFUPOEDUfojLWND0D%2F5kltVA737nn9lq4N7T4A%2F%2B2vhLAQB%2F8PcK%2F9ztjeZQIukY00SWRWA8aYA%2FmTXjyVRGD48mDUOe9ncxu%2Bp6wR%2F81fCXfDRVAF5rzQN%2F8HeOf6bTv%2FOM2a96nTP9I%2BNmwRfX50mfndOzJ99JzmSSXjtnvcnGR1PZs4B0Z5eqhaQr%2B1S7k%2FqBe9YzAbNmLGl4XkL%2B4Q914A%2F%2BmvhLAQB%2F8HeGv4Pp34Oser%2FD%2FFb%2Bxafkgp2C2fPN2bLp0ZyfO5szyTk7W7LM1uqM8o1Hs60quxRaqcwu288%2Blr%2FIJDvOZJ83Z3I68%2BycLV%2BYi4rOmE23R91EPfvVwLcqwR%2F8tfCXAgD%2B4O8e%2FpKSS3f8xt960RD4g%2F9T8Z%2FJj47XWQ%2FmqZWAD6%2FcAn%2Fw18JfCgD4g7%2B7%2BMu5X7%2Bz4lAz%2BIP%2FPPhLNlZ3CsoK%2Ba%2BKy%2BAP%2Fhr4SwEAf%2FB3B39Jacug7%2FiXtg6C%2F5%2FZu5efuM47jOP%2FRaN20YAUi0UkolqypTZZVF7EEovUkSq16sJVLFmqVEdZpMrCclWsLkpvOFFrx7ExvuBL4hvFpoodMIzBgMEz3DKYywAO2IbBMsYXIKRJdcIJYz2xfIEZZs7PvOe7%2BK69%2FDyvmfe84L9E%2FFVk9I4F%2FroaeKwV%2FME%2FaPw1AMAf%2FLOCv%2F3pH%2FzBfyn4q10N3tqKVm9i5iuzEdB8c8rL39sA%2FuAfFP4aAC%2FODwDwB%2F%2Fl468iw%2FcsTv%2FgD%2F5p4%2F%2BjVJvPXxXKBu2IfQH%2B4B8E%2FupoagCAP%2FhnBX899xtoU19%2B7f10dzf4g38G%2BKuKnnHTEfBmVQf4g39g%2BL%2FwcACAP%2FgvA3%2Bl534DbXdrEvzBP0P8VUFZszdwZ8ZsAPj%2FdsH%2BS%2BAP%2FkHgrwEA%2FuCfOf72p%2F%2FVO7vAH%2FyXgb8qOtkhlA060Z8Ef%2FAPAn8NAPAH%2F8zx14M%2FPclZi9M%2F%2BIP%2FsvFXF72SVsurgd94b9ddBX%2FwzzX%2BGgDgD%2F4Z4K%2F03G%2Bgjd6d817%2BoAP8wT9r%2BPvlf9To%2FzLfBH%2B%2Fqbn%2FeWuPtIA%2F%2BOcSfw0A8Af%2FNPBf5Lnf4NpWMwL%2B4J9F%2FNXaw636SmBQ%2BCt%2FgIA%2F%2BOcSfw0A8Af%2FTPDX6X%2FU5PS%2FqrQd%2FME%2Fy%2Fjrnf63L%2FQa4K9K2obBH%2Fxzhb8GAPiDf6b4v1zaOY%2Bxyekf%2FME%2FR%2FirE%2F1JA%2FxVUWUM%2FME%2FF%2FhrAIA%2F%2BAv%2FdIp5uy8nA8e%2FZ2LGP%2F2DP%2FjnCH9VsK%2FJf7kvYPzVwJR%2FNbAR%2FME%2Fa%2Fir6oUBAP7gnwn%2Bq%2F%2FV7V%2FDs3juF%2FzBP8f4qzf%2F02mAv6rovQn%2B4J9t%2FDUAwB%2F808X%2FxyU6%2FQf83C%2F4g39A%2BKsd0RED%2FNXmmjj4g3%2F28NcA6CkGf%2FBPD3%2FT0z%2F4g39A%2BKv8PboaGBz%2Byn%2BsaO3RFvAH%2F2zhrwEA%2FuCfBv5%2BJs%2F9tozeB3%2FwDxh%2F9dpRXQ0MDn9Vf30S%2FMF%2FufirY6kBAP7gnw7%2B6%2FddNXruNw7%2B4B8o%2Fmrhlb4%2FRPoN8FfbLyfAH%2FyzgX9qAPyxpxj8wX9x%2FG1P%2F2d6J8Ef%2FA3xV1WDtwzw11cCiyqj4A%2F%2By8VfAwD8wX8R%2FO1P%2Fwfi4A%2F%2BhvirVw4262pgYPir%2BO0HXv6%2BCPiD%2F3Lw1wAAf%2FB%2FJv7K5Lnfk%2FHb4A%2F%2Bygx%2F9evqriDxV7oaCP7gvxz8NQDAH%2FyXgv%2Bmk4NGz%2F12gj%2F4K1P81a7OUQP81cbz3eAP%2FpnirwEA%2FuC%2FCP5mp%2F%2FdbePgD%2F7KHH%2BVv7fB%2F%2B%2F4gPFX%2Fp8hCg9fAn%2FwzwR%2FDQDwB%2F9F8Lc8%2FYM%2F%2BD9n%2BKvXjulqoPAPIF0NBH%2FwzwR%2FDQDwB%2F9n4b%2FqHx1e4vaXFqd%2F8Af%2F5xR%2FtfXSgPA3aGtTP%2FiDf7r4awCAP%2FgL%2F8fb9pnRc787YuAP%2Fs8j%2FuqjheZP4gb462rgulOt4A%2F%2B6eCvAQD%2B4C%2FwHzv92zz3WzsC%2FuC%2FAvD3q%2FdeOZR6NTDwAaCrgXnl9eAP%2FgJ%2BqQMA%2FMH%2FOTz9gz%2F4rwj8H%2Fbbc91C2aCdXSPgD%2F7pDwDwB%2F9H04M%2FRqd%2F8Af%2FFYS%2FKvv8uukI%2BNWnHeAP%2Fkvs7MIAAH%2FwV8rkud%2Bxaf%2F0D%2F7gv4LwV%2FllF1NXA78xaeT%2BrFd4pBH8wX9R%2FF%2F4ODUAwB%2F8lfFzv6cT4A%2F%2BKxB%2FVVQZ83%2BYZzYCqoaS4A%2F%2Bi%2BGvAQD%2B4K9MT%2F%2FgD%2F4rGH%2B1vWVQKBv0bmMv%2BIP%2Fs%2FDXAAB%2F8P9%2BP98TNzn9v3U6Af7gv5LxV3vqza8GvnqiBfzB%2F2n4awCAP%2FhbP%2Fd7PjEF%2FuDvDP5%2Ba4%2B2eBMzX5mNgOjEPS9vfz34g7%2FwVxoA4A%2F%2B1s%2F9vn4gDv7g7wj%2BanNNXCgbVNp%2BDfzBX%2BgrDQDwB3%2FL0%2F%2BZ3knwB3%2Bn8Fd1%2FtO9piNgQ3UU%2FMH%2F6QMA%2FMHf742DfVanf%2FAHfyfx98vfF%2FEGpmZMrwYWVETAH%2FyfPADAH%2Fytnvs90nUL%2FMHfUfxVUWVUKBtUNZwEf%2FB%2F8gAAf%2FDfdMrmud%2Bf7OwEf%2FB3GH9VcmXIdARsicTBH%2FwfHwDgH0r81V9tTv8fto2DP%2Fi7jr%2FaW%2Bc1jU2ZXg1c88kl8Af%2FRwcA%2BIcZf9PTP%2FiDf2jw%2F%2BF8a441e0nDq4FNY3e8vAN14A%2F%2BqQHwp55i8A8v%2Fqv%2BafPc7%2FvNY%2BAP%2FiHCX22p7xHKBpVEB8Ef%2FDUAwD%2Bc%2BPttq7F57vel92PgD%2F4hw18dHxg3HQFFZ9vAP5z4q0%2B%2BGwCfF4N%2F%2BPDX6X%2FO4rlf8Af%2FEOKvCg42mF4NHJia9goO14N%2FePHXAAD%2FcOGv0%2F%2BI1ekf%2FME%2FpPirDWdjQtmgir4b4B9a%2FP3OLAwA8A8f%2Fqv%2F3WXy4M9756%2BBP%2FiHFn91wc%2F%2FVK%2Ft1cCLcfAPJ%2F4aAOAfDvxV1Nvdmgwc%2F9jYNPiDP%2Fj7%2BKfKK6%2F3f5lvNgCSM3PemuON4B8%2B%2FDUAwD9U%2BJud%2Ft%2BqTIA%2F%2BIO%2F8l%2Fq85%2Ft9e%2Fom42A%2Bhu3wT98%2BGsAgH9o8Lc8%2FYM%2F%2BIP%2FI%2FirLRHjq4GxQfAPF%2F4aAOAfHvzXl%2FcYnf4HwB%2F8wV%2F4P1bVUNL0K4FFZ1vBPzz4awCAfzjw9zvTa%2FDcb98k%2BIM%2F%2BAv%2FJ1Z4pNF%2Fuc%2FuauDdaS%2FvUC34hwN%2FDQDwdxx%2Fnf5tnvs9GAd%2F8Ad%2F4f%2FUNlQbXw3svw7%2B4cBfAwD8Hcbf%2FvQP%2FuAP%2FsJ%2F0XZ2j5iOgI21HeDvPv4aAODvPv6%2FPNJndfoHf%2FAH%2F7Kll7e%2F3otO3LW7Gjg75xV%2BHAF%2Ft%2FHXAAB%2FR%2FFXJs%2F9lseS4A%2F%2B4F%2BWbrXeqyebra8Ggr%2Fb%2BGsAgL%2Fb%2BG86lbB57ndXB%2FiDP%2Finld7p39rcJ5QNerepB%2Fzdw18dTw0A8HcNf%2FvT%2F4dt4%2BAP%2FuCfEf7q3MgtswEw8mDWy6uoBX838dcAAH9n8Lf%2F279O%2F%2BAP%2FuCfEf6q8GiD6dXAkvYE%2BLuJvwYA%2BLuEv%2F0v%2F%2F8cGQV%2F8Af%2FZeGvNtZ0mg2A%2BOR98HcTfw0A8HcKf%2FW3qH8aN3juNwr%2B4A%2F%2By8ZflfWMmo2An51uBH%2F38NcAAH838V%2B%2FP%2FgP%2F2yr%2FQL8wR%2F8s4K%2FyjtQ55%2FGTQbA7xu6wd8h%2FFXVwgAAf%2Ffw9%2Ftd1ZDF6R%2F8wR%2F8s4a%2FWld52eRq4F%2FaE%2BDvHv4aAODvEv7qnerhQAfAO%2F8dAn%2FwB%2F%2Fs4a%2FK%2FWq87W0DFp8HBn%2F38NcAAH9X8LcbALGxB%2BAP%2FuCfQ%2FxT%2BR%2FpCXQAlHYNgb97%2BGsAgL9L%2BKs3KnqDfO4X%2FMEf%2FHOGvyo8dtFLzswFNgCKr%2FSDv3v4awCAv0v4q1Wl7UGd%2FsEf%2FME%2F1%2FirQK8G%2FuLTNvB3C38NgHnci8HfNfxVy%2Bj93A6Ar%2F%2Fv%2FeZkH%2FiDP%2FgHgr%2Bq6LsRyMNALx6uAX%2F38NcAAH%2FX8FfvnbuWS%2Fz9537BH%2FzBPzD8Vd6hC97A3emcDoDjgzfB3y381YnUAAB%2Ft%2FBXV7xVpTH%2Fel5O8Pd7%2FVAc%2FMEf%2FIPBX%2B1fqOhsa06vBq470wz%2BjuL%2Fg4cDAPydxH%2Bhv1%2BZv543nBP8y9uT4A%2F%2B4G%2BCvyqJJXJ1%2Bgd%2Fd%2FHXAAB%2FV%2FFXkWv3sop%2FYnLWe%2BmDKPiDP%2Fgb4K8%2Bm%2B9b9u6ntYkgDuP4u%2FAmeFKoV4XiO%2FBYfQu%2Bi14KvYmIFL20lyAUtabUg6eStE2Lf9AkJgjpScMGrdCIFTFeRyaNPJdiM7O7zGT3u%2FBAG8j582RmfjvbujUwwzsALj%2Bpg39x8VcBAP%2Bi4q9cXWmb9tHvzPCfX%2BuAP%2FiDfwT421x6XDPN45%2BZHfy7sXUA%2FsXGXwUA%2FIuMvzK30javB7%2FAH%2FzBvzD4K1fWd8yrbz9S%2F%2FK%2FVt0H%2F%2BLjrwIA%2FsXH%2F6JilncHuiXQAf%2F17rGZe9gCf%2FAH%2F7jwVyrb5n7nkxf%2Ba72EZf%2Fy4K8CAP5lwV%2BZX%2B2aB2%2BOzpsQsEXBws9pf%2FAH%2F%2BjxV65X982jj327nP8%2F9O0EgT3sx2n%2FsuGvAtBdAv9S4K%2FcU%2BztfbefHprlvYG5e%2FDlX%2Bz%2F9nN70I85f%2FAH%2F%2BjxPzv2Fr%2BbL9%2FaG%2F3G2f363f7SH%2F99Z6%2FDS37Ki78KAPiXC3%2FlnaJwnz%2F4g39B8J%2BE%2B%2FzB%2F4y8OC0A4A%2F%2B4A%2F%2B4A%2F%2B4F8a%2FFUAwB%2F8wR%2F8wR%2F8wb80%2BKsAgD%2F4gz%2F4gz%2F4g39p8FcBAH%2FwB3%2FwB3%2FwB%2F%2FC469UJwUA%2FMEf%2FMEf%2FMEf%2FEuDvwoA%2BIM%2F%2BIM%2F%2BIM%2F%2BJcGfxUA8Ad%2F8J8d%2FG%2B1%2Fhifp1HLGf%2F60Ez%2FjEylCv7gD%2F6B8FcBAH%2FwB%2F%2B48VdapnJi%2FJ5%2BzwP%2FPAsA%2BIM%2F%2BAfCXwUA%2FMEf%2FKPGX3k2MIk7%2FUJ3wwX%2FvAsA%2BIM%2F%2BAfCXwUA%2FMEf%2FOPHX8v%2F%2Fk%2FSbjrgn3cBAH%2FwB%2F9A%2BKsAgD%2F4g%2F8sHPg7NA2T8jlJzEIuB%2F48CsAm%2BIM%2F%2BAfCXwUA%2FMEf%2FGfgtH%2FNAViPbQB%2F%2FH0LAPiDP%2FgHwl8FAPzBH%2FzjH%2FVb%2FCw%2BU24D5DHq51EAwB%2F8wT8Q%2FioA4A%2F%2B4B%2F5nL%2FD8r%2FzNkB6%2FD0LAPiDP%2FgHwl8FAPzBH%2Fwjxt9h%2Bd99GyA9%2Fv4FAPzBH%2FxD4K8CsNxdAn%2FwB%2F9Y8beZdvZ%2FaBp9h3cCpMc%2FZQEAf%2FAH%2FzD422ydFgDwB3%2Fwjw5%2FRbP%2F5y7tL7ZHUwI8NIsp8U9fAMAf%2FME%2FFP4XNicFAPzBH%2Fxjw19ZmHb2v99z2ipo1L3xz6gAgD%2F4g38g%2FFUAwB%2F8wT8i%2FN2X%2F%2FWu%2F43EJA6vBvbAP8MCAP7gD%2F6B8FcBAH%2FwB%2F9I8Hdf%2FteS%2FvhQX1OFYZrvuOGfcQEAf%2FAH%2F0D4qwCAP%2FiDf2T4a%2Fbf%2BaKfhfYou20A4Z9DAQB%2F8Af%2FQPirAIA%2F%2BIN%2FRPh7zP7rqt8MtwGEf04FAPzBH%2FwD4a8CAP7gD%2F6R4O8%2B%2B6%2FlfxttA0wP8fNU%2BCs7rgUA%2FMEf%2FAPhrwIA%2FuAP%2FsHx91%2F%2B15v9vLYBkg%2Fv0%2BO%2F6lMAwB%2F8wT8Q%2FioA4A%2F%2B4B8H%2FkrvL3t3jNtEFEVheBWkQGJRXo%2BbNOyBAAUtUUiyATu4BITcEFrbbVKQgtQPj2J0Gsvje%2Be9nEH8I9027ffnXc%2B8ssh%2F2z%2F25cBf6zIZhH82AMAf%2FMHfhL8CAPzBH%2FzHhP%2BiTL4%2FDrjdr8O8C4jIGiCPfz4AwB%2F8wd%2BEvwIA%2FMEf%2FEeD%2F3a0wx9ysc90VSJrgDT%2B%2BQAAf%2FAHfxP%2BCgDwB3%2FwHwn%2B3XzclE30%2BF%2F4a2bBNUAOf838LhgA4A%2F%2B4G%2FCXwEA%2FuAP%2FqPAP3n8L%2Fw10TVAKYtZHH%2FNPBEA4A%2F%2B4O%2FC%2F%2BRyFwDgD%2F7gb8c%2Fd%2Fy%2FF%2F%2FcGqCsbrP4JwMA%2FMEf%2FD34d3PZBcDyFPzBH%2FzHgL9%2BvX%2Fk8f8e%2FFNrAH1PIIF%2FPgDAH%2FzB34S%2FAgD8wR%2F8%2Ffh3R%2FnTVQDQ8x78U2uAOP75AAB%2F8Ad%2FE%2F4KAPAHf%2FB349%2BNsA68u6%2BpswYI458PAPAHf%2FA34a8AAH%2FwB383%2Fjr%2Bj3%2B9r%2FIaIIh%2FPgDAH%2FzB34S%2FAgD8wR%2F8nfjr%2BD%2F%2B%2Ff4Wa4AQ%2FpqbaACAP%2FiDvwl%2FBQD4gz%2F42%2FDXDX51j%2F81Z1oDHP33j8dfV%2FpGA%2BAS%2FMEf%2FE34KwDAH%2FzB34e%2FLu%2FxP%2FrvPIh%2FKgDAH%2FzB34S%2FAgD8wR%2F8Tfjr%2Bt5RPZvl1wD%2B2QAAf%2FAHfxP%2BCgDwB3%2Fw9%2BCv4%2F%2BRPQ%2FrMgngnwsA8Ad%2F8Hfhf3K1CwDwB3%2FwN%2BAfOP73rAEC%2BKcCAPzBH%2FxN%2BCsAwB%2F8wd%2BAf%2BDdf88a4EsP%2FkMDAPzBH%2Fwd%2BCsAXi9PwR%2F8wd%2BAv979H%2BlzV6Y9%2BA8LAPAHf%2FA34a8AAH%2FwB38D%2Fnr3f7TPYt6Pfz4AwB%2F8wd%2BDfzefngIA%2FMEf%2FBvinz%2F%2B9z%2BrW%2BFfPQDAH%2FzB34S%2FAgD8wR%2F8G%2BOfP%2F73rwGE%2FIGZJQIA%2FMEf%2FE34KwDAH%2FzBvy3%2B%2BXf%2F%2Fc%2Fiphf%2FZACAP%2FiDvwl%2FBQD4gz%2F4t8I%2F8O5%2F5PO%2FZ3%2Fn5vh5u5v5fXQN0IN%2FNgDAH%2FzB34S%2FAgD8wR%2F8W%2BBf791%2F3f6Xx19zWxZV1gCzgQEA%2FuAP%2Fib8FQDgD%2F7g3xL%2F%2FPG%2Fbv%2Brgb9mugp%2FE%2BAw%2Fu%2BjAfC7fLgCf%2FAHfxP%2BCgDwB3%2Fwb46%2F5nwdP%2F6vh7%2Fu7o88D6syOYB%2FLgDAH%2FzB34X%2FyfUuAMAf%2FMG%2FLf6az4n%2Fvr%2FVxL8brQFCnwbej38%2BAMAf%2FMHfhL8CAPzBH%2FyfB%2F%2BXb37G4b2oiL8mswbYi38%2BAMAf%2FMHfhL8CAPzBH%2FyfA%2F%2FtzO5LiR7%2F18c%2FvwYQ%2FhUCAPzBH%2FxN%2BCsAwB%2F8wb81%2Ft2kjv%2Bb4J9fAwj84QEA%2FuAP%2Fgb8FQCvtgEA%2FuAP%2Fq3xzx7%2FV8df8y6%2BBijrHxUDAPzBH%2FxN%2BCsAwB%2F8wb8V%2FprJ8jF%2B%2FN8Kf32%2FP%2F5p4GoBAP7gD%2F4u%2FF9cXzwFAPiDP%2Fi3wD8yqff88%2Fj3zKFf%2B2u4zx%2F8wf8fxV8BAP7gD%2F7gD%2F7gD%2F7%2FDf4KAPAHf%2FD%2F026d20gVBVAQJYgh3%2B8hDNJgtdhJYYQ6JkD0Q9cgg6ljVAyn4A9%2F%2BMM%2Fg%2F8GAP7whz%2F84Q9%2F%2BGfw3wDAH%2F7whz%2F84Q%2F%2FAv6nj2cA4A9%2F%2BMMf%2FvCHfwf%2FMwC3C%2F7whz%2F84Q9%2F%2BGfw3wDAH%2F7whz%2F84Q%2F%2FDP4bAPjDH%2F7whz%2F84Z%2FBfwMAf%2FjDH%2F7whz%2F8G%2FhvAF7cLvjDH%2F7whz%2F84Z%2FBfwMAf%2FjDH%2F7whz%2F8E%2FifPtwHAP7whz%2F84Q9%2F%2BGfw3wDAH%2F7whz%2F84Q%2F%2FDP4bAPjDH%2F7whz%2F84V%2FA%2F%2FTpDAD84Q9%2F%2BMMf%2FvDP4L8BgD%2F84Q9%2F%2BMMf%2Fhn8NwDwhz%2F84Q9%2F%2BMM%2Fg%2F8GAP7whz%2F84Q9%2F%2BGfw3wDAH%2F7whz%2F84Q%2F%2FDP4bAPjDH%2F7whz%2F84Z%2FBfwMAf%2FjDH%2F7whz%2F8M%2FhvAOAPf%2FjDH%2F7wh38G%2Fw0A%2FOEPf%2FjDH%2F7wz%2BC%2FAYA%2F%2FOEPf%2FjDH%2F4J%2FE%2Fv7wMAf%2FjDH%2F7whz%2F8O%2Fg%2F%2F3wGAP7whz%2F84Q9%2F%2BGfw3wDAH%2F7whz%2F84Q%2F%2FDP4bAPjDH%2F7whz%2F84Z%2FBfwMAf%2FjDH%2F7whz%2F8M%2FhvAOAPf%2FjDH%2F7wh38G%2Fw0A%2FOEPf%2FjDH%2F7wz%2BC%2FAYA%2F%2FOEPf%2FjDH%2F4Z%2FDcA8Ic%2F%2FOEPf%2FjDP4P%2FBgD%2B8Ic%2F%2FOEPf%2Fg38N8AvLxd8Ic%2F%2FOEPf%2FjDP4P%2FBgD%2B8Ic%2F%2FOEPf%2Fhn8N8AwB%2F%2B8Ic%2F%2FOEP%2FwL%2Bpy9%2FB%2BDnBX%2F4wx%2F%2B8Ic%2F%2FDP4bwDgD3%2F4wx%2F%2B8Id%2FAv%2FTu%2FsAwB%2F%2B8Ic%2F%2FOEP%2Fwz%2BGwD4wx%2F%2B8Ic%2F%2FOGfwX8DAH%2F4wx%2F%2B8Ic%2F%2FDP4bwDgD3%2F4wx%2F%2B8Id%2FBv8NAPzhD3%2F4wx%2F%2B8M%2FgvwGAP%2FzhD3%2F4wx%2F%2BGfw3APCHP%2FzhD3%2F4wz%2BD%2FwYA%2FvCHP%2FzhD3%2F4Z%2FDfAMAf%2FvCHP%2FzhD%2F8M%2FhsA%2BMMf%2FvCHP%2Fzhn8F%2FAwB%2F%2BMMf%2FvCHP%2FwL%2BJ%2B%2BngGAP%2FzhD3%2F4wx%2F%2BGfw3APCHP%2FzhD3%2F4wz%2BD%2FwYA%2FvCHP%2FzhD3%2F4Z%2FDfAMAf%2FvCHP%2FzhD%2F8M%2FhsA%2BMMf%2FvCHP%2Fzhn8D%2F9PbXsz%2BoX%2FCHP%2FzhD3%2F4wz%2BD%2FwYA%2FvCHP%2FzhD3%2F4Z%2FDfAMAf%2FvCHP%2FzhD%2F8M%2FhsA%2BMMf%2FvCHP%2Fzhn8F%2FAwB%2F%2BMMf%2FvCHP%2Fwz%2BG8A4A9%2F%2BMMf%2FvCHfwb%2FDQD84Q9%2F%2BMMf%2FvAv4H%2F6dgYA%2FvCHP%2FzhD3%2F4d%2FB%2F%2BDcA8Ic%2F%2FOEPf%2FjDP4P%2FBgD%2B8Ic%2F%2FOEPf%2Fhn8N8AwB%2F%2B8Ic%2F%2FOEP%2Fwz%2BGwD4wx%2F%2B8Ic%2F%2FOGfwX8DAH%2F4wx%2F%2B8Ic%2F%2FDP4bwDgD3%2F4wx%2F%2B8Id%2FBP8NwOMFf%2FjDH%2F7whz%2F8M%2FhvAOAPf%2FjDH%2F7wh38C%2F9Ob%2BwDAH%2F7whz%2F84Q%2F%2FDP4bAPjDH%2F7whz%2F84Z%2FBfwMAf%2FjDH%2F7whz%2F8M%2FhvAOAPf%2FjDH%2F7wh38B%2F9P3MwDwhz%2F84Q9%2F%2BMM%2Fg%2F8ZgFePF%2FzhD3%2F4wx%2F%2B8M%2FgvwGAP%2FzhD3%2F4wx%2F%2BGfw3APCHP%2FzhD3%2F4wz%2BD%2FwYA%2FvCHP%2FzhD3%2F4Z%2FDfAMAf%2FvCHP%2FzhD%2F8M%2FhsA%2BMMf%2FvCHP%2Fzhn8F%2FAwB%2F%2BMMf%2FvCHP%2Fwz%2BG8A4A9%2F%2BMMf%2FvCHfwb%2FDQD84Q9%2F%2BMMf%2FvDP4L8BgD%2F84Q9%2F%2BMMf%2Fhn8NwDwhz%2F84Q9%2F%2BMM%2Fgf%2Fp9X0A4A9%2F%2BMMf%2FvCHfwf%2Fhx9nAOAPf%2FjDH%2F7wh38G%2Fw0A%2FOEPf%2FjDH%2F7wz%2BC%2FAYA%2F%2FOEPf%2FjDH%2F4Z%2FDcA8Ic%2F%2FOEPf%2FjD%2Fynj%2F3%2B%2FAVWqM3LLwAStAAAAAElFTkSuQmCC"},{}],dz0fj:[function(e,t,F){var a=e("@parcel/transformer-js/src/esmodule-helpers.js");function r(e){if(!e||"string"!=typeof e.title||"string"!=typeof e.description||!Array.isArray(e.keywords)||"string"!=typeof e.category)throw Error("Respons AI tidak sesuai format metadata.");let t=e=>e.replace(/\s+/g," ").trim(),F=(e,F)=>{let a=t(e);if(a.length<=F)return a;let r=a.slice(0,F),n=r.lastIndexOf(" ");return`${r.slice(0,n>80?n:F).trim()}`};return{title:F(e.title,180),description:F(e.description,190),keywords:e.keywords.map(e=>String(e).trim()).filter(Boolean).slice(0,49),category:e.category.trim()}}async function n(e,t,F,a){let n;if(!e?.trim())throw Error("Kode aktivasi tidak ditemukan. Buka popup extension dan aktivasi ulang.");let i=new AbortController,o=setTimeout(()=>i.abort(),12e4);try{n=await fetch("https://autofillstock.my.id/api/extension/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({activationCode:e,assetBrief:t,filename:F,platform:a}),signal:i.signal})}catch(e){if(e instanceof Error&&"AbortError"===e.name)throw Error("Generate timeout. Server terlalu lama merespons. Coba lagi.");throw Error("Tidak dapat menghubungi server. Periksa koneksi internet dan coba lagi.")}finally{clearTimeout(o)}let s=await n.text(),l={};try{l=s?JSON.parse(s):{}}catch{if(504===n.status||/gateway time-?out/i.test(s))throw Error("Server timeout saat generate. Coba lagi beberapa detik.");throw Error(`Server error (${n.status}). Coba lagi.`)}if(!n.ok)throw Error(l?.error||`Gagal generate metadata (${n.status}).`);return r(l.metadata)}async function i(e,t){let F,a;let n=`Generate microstock contributor metadata for a digital asset.
Return strict JSON only with this shape:
{"title":"...","description":"...","keywords":["..."],"category":"..."}
Rules: description is the primary contributor text that will be pasted into the microstock description field and it must be 120 to 190 characters, one sentence, no line breaks. Title can be a short fallback summary under 180 characters. Keywords must contain 45 to 49 unique, relevant microstock search terms, ordered from most important to supporting terms. Avoid duplicates, filler, brand names, and irrelevant words. Category must match the user's supplied category when one is present. When available categories are supplied, choose only one category from that list. Strongly prioritize the original file name over generic keyword suggestions.
Asset brief: ${t||"A general commercial stock asset; infer broadly useful metadata."}`;try{F=await fetch("https://api.openai.com/v1/chat/completions",{method:"POST",headers:{Authorization:`Bearer ${e}`,"Content-Type":"application/json"},body:JSON.stringify({model:"gpt-4o-mini",temperature:.4,response_format:{type:"json_object"},messages:[{role:"system",content:"You are a metadata assistant for microstock contributors. Output only valid JSON."},{role:"user",content:n}]})})}catch(e){throw Error("Tidak dapat menghubungi OpenAI. Periksa koneksi internet dan coba lagi.")}try{a=await F.json()}catch{throw Error("OpenAI mengembalikan respons yang tidak valid.")}if(!F.ok)throw Error(a?.error?.message||"Gagal menghubungi OpenAI API.");let i=a?.choices?.[0]?.message?.content;if("string"!=typeof i)throw Error("OpenAI tidak mengembalikan konten metadata.");return r(function(e){let t=e.match(/```(?:json)?\s*([\s\S]*?)```/),F=t?.[1]??e,a=F.indexOf("{"),r=F.lastIndexOf("}");if(-1===a||-1===r)throw Error("Respons AI tidak berisi JSON.");return JSON.parse(F.slice(a,r+1))}(i))}a.defineInteropFlag(F),a.export(F,"generateMetadataViaServer",()=>n),a.export(F,"generateMetadata",()=>i)},{"@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],fRZO2:[function(e,t,F){F.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},F.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},F.exportAll=function(e,t){return Object.keys(e).forEach(function(F){"default"===F||"__esModule"===F||t.hasOwnProperty(F)||Object.defineProperty(t,F,{enumerable:!0,get:function(){return e[F]}})}),t},F.export=function(e,t,F){Object.defineProperty(e,t,{enumerable:!0,get:F})}},{}],jsYik:[function(e,t,F){var a=e("@parcel/transformer-js/src/esmodule-helpers.js");a.defineInteropFlag(F),a.export(F,"getSettings",()=>i),a.export(F,"updateSettings",()=>o),a.export(F,"clearApiKey",()=>s);let r={activation_status:!1,panel_enabled:!1,selected_microstock:"adobe_stock",usage_count:0};function n(){return"undefined"!=typeof chrome&&!!chrome.storage?.local}async function i(){if(!n())return r;let e=await chrome.storage.local.get(Object.keys(r)),t=await chrome.storage.local.get(["activation_code","openai_api_key","last_generated"]);return{...r,...e,...t}}async function o(e){n()&&await chrome.storage.local.set(e)}async function s(){n()&&await chrome.storage.local.remove("openai_api_key")}},{"@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}]},["WfXo6"],"WfXo6","parcelRequire51e0"),globalThis.define=t;